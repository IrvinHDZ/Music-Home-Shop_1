package Proyecto;

public class Ventas {
	private int Id,Total,Total_Productos;
	private String Fecha, IdVendedor;
	
	public Ventas(int id, int total, int total_Productos, String fecha, String idVendedor) {
		Id = id;
		Total = total;
		Total_Productos = total_Productos;
		Fecha = fecha;
		IdVendedor = idVendedor;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public int getTotal() {
		return Total;
	}

	public void setTotal(int total) {
		Total = total;
	}

	public int getTotal_Productos() {
		return Total_Productos;
	}

	public void setTotal_Productos(int total_Productos) {
		Total_Productos = total_Productos;
	}

	public String getFecha() {
		return Fecha;
	}

	public void setFecha(String fecha) {
		Fecha = fecha;
	}

	public String getIdVendedor() {
		return IdVendedor;
	}

	public void setIdVendedor(String idVendedor) {
		IdVendedor = idVendedor;
	}
	
	
	
}
