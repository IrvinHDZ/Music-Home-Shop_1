package Proyecto;

import java.applet.AudioClip;
import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;
import java.awt.Font;

public class JFrameInventario extends JFrame {
	int pos=0;
	public	AudioClip sonido;
	ResultSet rs;
	PreparedStatement ps;
	boolean modoAgregar=false,modoEliminar=false,modoModificar=false;
	private JPanel contentPane;
	private JTextField txtMax;
	private JTextField txtInvAct;
	private JTextField txtMin;
	private JButton btnI;
	private JButton btnA;
	private JButton btnS;
	private JButton btnU;
	private JButton btnAgregar;
	private JButton btnModificar;
	private JButton btnEliminar;
	private JButton btnConfirmar;
	private JButton btnCancelar;
	private JTextField txtRegistro;
	private JLabel lblModo;
	private JComboBox comboBox;
	private JSpinner spinnerMax;
	private JSpinner spinnerMin;
	private JTextField txtIdPro;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JFrameInventario frame = new JFrameInventario();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public JFrameInventario() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(JFrameInventario.class.getResource("/Imagenes/applications.png")));
		Connection con = conexion();
		Icon ico = new ImageIcon(getClass().getResource("/Proyecto/icono.gif"));
		
		setTitle("Base de Datos del Inventario");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 750, 340);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtIdPro = new JTextField();
		txtIdPro.setEnabled(false);
		txtIdPro.setBounds(142, 7, 145, 23);
		contentPane.add(txtIdPro);
		
		JLabel lblId = new JLabel("Id Producto: ");
		lblId.setBounds(10, 11, 122, 14);
		contentPane.add(lblId);
		
		JLabel lblCompa = new JLabel("Maximo:");
		lblCompa.setBounds(10, 74, 122, 14);
		contentPane.add(lblCompa);
		
		txtMax = new JTextField();
		txtMax.setEnabled(false);
		txtMax.setBounds(142, 71, 145, 20);
		contentPane.add(txtMax);
		txtMax.setColumns(10);
		
		JLabel lblDire = new JLabel("Inventario Actual:");
		lblDire.setBounds(10, 183, 122, 14);
		contentPane.add(lblDire);
		
		txtInvAct = new JTextField();
		txtInvAct.setEnabled(false);
		txtInvAct.setBounds(142, 180, 145, 20);
		contentPane.add(txtInvAct);
		txtInvAct.setColumns(10);
		
		JLabel lblRfc = new JLabel("Minimo:");
		lblRfc.setBounds(10, 134, 122, 14);
		contentPane.add(lblRfc);
		
		txtMin = new JTextField();
		txtMin.setEnabled(false);
		txtMin.setBounds(142, 131, 145, 20);
		contentPane.add(txtMin);
		txtMin.setColumns(10);
		
		JButton btnSalir = new JButton(" Salir");
		btnSalir.setIcon(new ImageIcon(JFrameInventario.class.getResource("/Imagenes/stock_exit.png")));
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnSalir.setBounds(604, 226, 120, 31);
		contentPane.add(btnSalir);
		
		btnI = new JButton("Inicio");
		btnI.setIcon(new ImageIcon(JFrameInventario.class.getResource("/Imagenes/control_stop_left.png")));
		btnI.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pos = 0;
	            ShowPosInfo(pos);
			}
		});
		btnI.setBounds(10, 268, 139, 28);
		contentPane.add(btnI);
		
		btnA = new JButton("Anterior");
		btnA.setIcon(new ImageIcon(JFrameInventario.class.getResource("/Imagenes/control_double_left.png")));
		btnA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pos--;
	            if(pos >= 0){
	                ShowPosInfo(pos);                
	            }
	            else{
	            	if(pos < 0){
	            		sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
	                    sonido.play(); 
	            		JOptionPane.showMessageDialog(null, "Ya es el primer registro","",JOptionPane.ERROR_MESSAGE,ico);
		                    pos = 0;            
		            }
	                
	            }
				
			}
		});
		btnA.setBounds(159, 268, 139, 28);
		contentPane.add(btnA);
		
		btnS = new JButton("Siguiente");
		btnS.setIcon(new ImageIcon(JFrameInventario.class.getResource("/Imagenes/control_double_right.png")));
		btnS.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pos++;
	               if(pos < BindList().size()){
	                   ShowPosInfo(pos);
	               }
	               else{
	                   pos = BindList().size() - 1;
	                   ShowPosInfo(pos);
	                   sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
	                   sonido.play();
	           		JOptionPane.showMessageDialog(null, "Ya es el ultimo registro","",JOptionPane.ERROR_MESSAGE,ico);
	               }
			}
		});
		btnS.setBounds(436, 268, 139, 28);
		contentPane.add(btnS);
		
		btnU = new JButton("Ultimo");
		btnU.setIcon(new ImageIcon(JFrameInventario.class.getResource("/Imagenes/control_stop_right.png")));
		btnU.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pos = BindList().size() - 1;
				ShowPosInfo(pos);
			}
		});
		btnU.setBounds(585, 268, 139, 28);
		contentPane.add(btnU);
		
		btnAgregar = new JButton(" Agregar");
		btnAgregar.setIcon(new ImageIcon(JFrameInventario.class.getResource("/Imagenes/add.png")));
		btnAgregar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				spinnerMax.setValue(0);
				
				modoAgregar=true;
				
				lblModo.setText("Modo: Agregar");
				
				btnAgregar.setVisible(false);
				btnModificar.setVisible(false);
				btnEliminar.setVisible(false);
				btnSalir.setVisible(false);
				btnI.setVisible(false);
				btnA.setVisible(false);
				btnS.setVisible(false);
				btnU.setVisible(false);
				txtIdPro.setVisible(false);
				txtRegistro.setVisible(false);
				
				btnCancelar.setVisible(true);
				btnConfirmar.setVisible(true);
				
				txtMax.setVisible(false);
				txtMin.setVisible(false);
				spinnerMax.setVisible(true);
				spinnerMax.setEnabled(true);
				spinnerMin.setVisible(true);
				spinnerMin.setEnabled(true);
				
				
				txtInvAct.setEnabled(true);
				comboBox.setEnabled(true);
				
				txtMax.setText("");
				txtMin.setText("");
				txtInvAct.setText("");
				
				
				
				
			}
		});
		btnAgregar.setBounds(10, 226, 120, 31);
		contentPane.add(btnAgregar);
		
		btnModificar = new JButton(" Modificar");
		btnModificar.setIcon(new ImageIcon(JFrameInventario.class.getResource("/Imagenes/refresh.png")));
		btnModificar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				comboBox.setSelectedItem(txtIdPro.getText());
				
				int valor=0,valor2=0;
				valor=Integer.parseInt(txtMax.getText());
				spinnerMax.setValue(valor);
				
				valor2=Integer.parseInt(txtMin.getText());
				spinnerMin.setValue(valor2);
				
				modoModificar=true;
				
				lblModo.setText("Modo: Modificar");
				
				btnAgregar.setVisible(false);
				btnModificar.setVisible(false);
				btnEliminar.setVisible(false);
				btnSalir.setVisible(false);
				btnI.setVisible(false);
				btnA.setVisible(false);
				btnS.setVisible(false);
				btnU.setVisible(false);
				txtRegistro.setVisible(false);
				txtIdPro.setVisible(false);
				btnCancelar.setVisible(true);
				btnConfirmar.setVisible(true);
				
				txtMax.setEnabled(true);
				txtMin.setEnabled(true);
				txtInvAct.setEnabled(true);
				comboBox.setEnabled(true);
				
				txtMax.setVisible(false);
				txtMin.setVisible(false);
				spinnerMax.setVisible(true);
				spinnerMax.setEnabled(true);
				spinnerMin.setVisible(true);
				spinnerMin.setEnabled(true);
				
			}
		});
		btnModificar.setBounds(207, 226, 120, 31);
		contentPane.add(btnModificar);
		
		btnEliminar = new JButton(" Eliminar");
		btnEliminar.setIcon(new ImageIcon(JFrameInventario.class.getResource("/Imagenes/trash_can.png")));
		btnEliminar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				modoEliminar=true;
				
				lblModo.setText("Modo: Eliminar");
				
				btnAgregar.setVisible(false);
				btnModificar.setVisible(false);
				btnEliminar.setVisible(false);
				btnSalir.setVisible(false);
				btnI.setVisible(false);
				btnA.setVisible(false);
				btnS.setVisible(false);
				btnU.setVisible(false);
				txtRegistro.setVisible(false);
				
				btnCancelar.setVisible(true);
				btnConfirmar.setVisible(true);
				
				
			}
		});
		btnEliminar.setBounds(392, 226, 120, 31);
		contentPane.add(btnEliminar);
		
		btnConfirmar = new JButton(" Confirmar");
		btnConfirmar.setIcon(new ImageIcon(JFrameInventario.class.getResource("/Imagenes/tick_circle.png")));
		btnConfirmar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int confirmado = JOptionPane.showConfirmDialog(null,"Presione YES para confirmar. \nPresione NO para anular accion.","Confirmacion",JOptionPane.YES_NO_OPTION);

				if (JOptionPane.YES_OPTION == confirmado) {
					
					String  inAct, id;
					int maximo, minimo;
					
					if (modoAgregar == true) {
						
						maximo = (Integer) spinnerMax.getValue();
						minimo = (Integer) spinnerMin.getValue();
						inAct = txtInvAct.getText();
						
						id=(String) comboBox.getSelectedItem();
				 		int i=0;
						String aux="";
						if(id.contains(".")) {
				 			while(id.charAt(i)!='.') {
				 			aux=aux+id.substring(i,(i+1));
				 			i++;
				 		}
				 			}else {
				 				aux=id;
				 			}
				 		
						
						
						Connection con = conexion();

						if (maximo==0 || inAct.isEmpty()) {
							sonido = java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
							sonido.play();
							JOptionPane.showMessageDialog(null, "Error al momento de agregar", "",JOptionPane.ERROR_MESSAGE, ico);
						} else {
							String sqlInsert = "INSERT INTO inventario(`Id_Producto`, `M�ximo`, `M�nimo`, `Inventario_Actual`) values ('"+ aux + "','"+ maximo + "','" + minimo + "','" + inAct + "')";
							try {
								Statement stmt = con.createStatement();
								stmt.executeUpdate(sqlInsert);
								JOptionPane.showMessageDialog(btnAgregar, "Se ha guardado el Registro", "Insertar",JOptionPane.INFORMATION_MESSAGE);

							} catch (Exception e1) {
								sonido = java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
								sonido.play();
								JOptionPane.showMessageDialog(null, "Error al agregar", "", JOptionPane.ERROR_MESSAGE, ico);
							}
						}
						
						
						
						modoAgregar = false;
						lblModo.setText("Modo: Lectura");
						
						lblId.setVisible(true);
						comboBox.setVisible(true);
						btnAgregar.setVisible(true);
						btnModificar.setVisible(true);
						btnEliminar.setVisible(true);
						btnSalir.setVisible(true);
						btnI.setVisible(true);
						btnA.setVisible(true);
						btnS.setVisible(true);
						btnU.setVisible(true);
						txtRegistro.setVisible(true);
						
						btnCancelar.setVisible(false);
						btnConfirmar.setVisible(false);
						txtIdPro.setVisible(true);
						txtMax.setEnabled(false);
						txtMin.setEnabled(false);
						txtInvAct.setEnabled(false);
						comboBox.setEnabled(false);
					
						txtMax.setText("");
						txtMin.setText("");
						txtInvAct.setText("");
						
						txtMax.setVisible(true);
						txtMin.setVisible(true);
						spinnerMax.setVisible(false);
						spinnerMax.setEnabled(false);
						spinnerMin.setVisible(false);
						spinnerMin.setEnabled(false);
						
						ShowPosInfo(0);
					}

					if (modoModificar == true) {

						maximo = (Integer) spinnerMax.getValue();
						minimo = (Integer) spinnerMin.getValue();
						inAct = txtInvAct.getText();
						
						id=(String) comboBox.getSelectedItem();
				 		int i=0;
						String aux="";
						if(id.contains(".")) {
				 			while(id.charAt(i)!='.') {
				 			aux=aux+id.substring(i,(i+1));
				 			i++;
				 		}
				 			}else {
				 				aux=id;
				 			}

						
						
						Connection con = conexion();
						
						 String sqlupdate = "UPDATE inventario SET `Id_Producto`='"+ aux +"',`M�ximo`='"+ maximo +"',`M�nimo`='"+ minimo +"',`Inventario_Actual`='"+ inAct +"' WHERE Id_Producto = " + aux;
						 
						 if(maximo==0 || inAct.isEmpty()) {
						 JOptionPane.showMessageDialog(null, "Error al momento de modificar :(","ERROR!!!" ,JOptionPane.ERROR_MESSAGE);
						sonido = java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
						sonido.play();
						Icon ico = new ImageIcon(getClass().getResource("/Proyecto/icono.gif"));
						JOptionPane.showMessageDialog(null, "Error al momento de modificar", "", JOptionPane.ERROR_MESSAGE,
								ico);
						 }else {
						try {
							Statement stmt = con.createStatement();
							 stmt.executeUpdate(sqlupdate);
							JOptionPane.showMessageDialog(btnAgregar, "Se han confirmado los cambios", "Modificar",
									JOptionPane.INFORMATION_MESSAGE);
						} catch (Exception e1) {
							sonido = java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
							sonido.play();
							JOptionPane.showMessageDialog(null, "Error al momento de modificar", "",
									JOptionPane.ERROR_MESSAGE, ico);
						}
						 }

						modoModificar = false;
						lblModo.setText("Modo: Lectura");
						
						lblId.setVisible(true);
						comboBox.setVisible(true);
						btnAgregar.setVisible(true);
						btnModificar.setVisible(true);
						btnEliminar.setVisible(true);
						btnSalir.setVisible(true);
						btnI.setVisible(true);
						btnA.setVisible(true);
						btnS.setVisible(true);
						btnU.setVisible(true);
						txtRegistro.setVisible(true);
						txtIdPro.setVisible(true);
						btnCancelar.setVisible(false);
						btnConfirmar.setVisible(false);
						
						txtMax.setEnabled(false);
						txtMin.setEnabled(false);
						comboBox.setEnabled(false);
						txtInvAct.setEnabled(false);
					
						txtMax.setText("");
						txtMin.setText("");
						txtInvAct.setText("");
						
						txtMax.setVisible(true);
						txtMin.setVisible(true);
						spinnerMax.setVisible(false);
						spinnerMax.setEnabled(false);
						spinnerMin.setVisible(false);
						spinnerMin.setEnabled(false);
						
						ShowPosInfo(pos);
					}
					if (modoEliminar == true) {
						
						id=(String) comboBox.getSelectedItem();
				 		int i=0;
						String aux="";
						if(id.contains(".")) {
				 			while(id.charAt(i)!='.') {
				 			aux=aux+id.substring(i,(i+1));
				 			i++;
				 		}
				 			}else {
				 				aux=id;
				 			}
						
						 String SqlSt = "DELETE FROM inventario WHERE Id_Producto= "+ aux;
						Connection con = conexion();
						try {
							Statement stmt = con.createStatement();
							 stmt.executeUpdate(SqlSt);

							JOptionPane.showMessageDialog(btnEliminar, "Eliminacion Exitosa", "Eliminar",JOptionPane.INFORMATION_MESSAGE);
						} catch (Exception e1) {
							sonido = java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
							sonido.play();
							JOptionPane.showMessageDialog(null, "No se pudo eliminar", "", JOptionPane.ERROR_MESSAGE, ico);
						}

						modoEliminar = false;
						
						lblModo.setText("Modo: Lectura");
						
						lblId.setVisible(true);
						comboBox.setVisible(true);
						btnAgregar.setVisible(true);
						btnModificar.setVisible(true);
						btnEliminar.setVisible(true);
						btnSalir.setVisible(true);
						btnI.setVisible(true);
						btnA.setVisible(true);
						btnS.setVisible(true);
						btnU.setVisible(true);
						txtRegistro.setVisible(true);
						txtIdPro.setVisible(true);
						btnCancelar.setVisible(false);
						btnConfirmar.setVisible(false);
						
						txtMax.setEnabled(false);
						txtMin.setEnabled(false);
						comboBox.setEnabled(false);
						txtInvAct.setEnabled(false);
					
						txtMax.setText("");
						txtMin.setText("");
						txtInvAct.setText("");
						
						txtMax.setVisible(true);
						txtMin.setVisible(true);
						spinnerMax.setVisible(false);
						spinnerMax.setEnabled(false);
						spinnerMin.setVisible(false);
						spinnerMin.setEnabled(false);
						
						ShowPosInfo(0);
					}
				   }
				else {
					
				}
				
				
						
			}
		});
		btnConfirmar.setBounds(306, 200, 135, 31);
		btnConfirmar.setVisible(false);
		contentPane.add(btnConfirmar);
		
		btnCancelar = new JButton(" Cancelar");
		btnCancelar.setIcon(new ImageIcon(JFrameInventario.class.getResource("/Imagenes/no.png")));
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				modoAgregar=false;
				modoEliminar=false;
				modoModificar=false;
				
				lblModo.setText("Modo: Lectura");
				
				lblId.setVisible(true);
				comboBox.setVisible(true);
				btnAgregar.setVisible(true);
				btnModificar.setVisible(true);
				btnEliminar.setVisible(true);
				btnSalir.setVisible(true);
				btnI.setVisible(true);
				btnA.setVisible(true);
				btnS.setVisible(true);
				btnU.setVisible(true);
				txtRegistro.setVisible(true);
				
				btnCancelar.setVisible(false);
				btnConfirmar.setVisible(false);
				
				txtMax.setEnabled(false);
				txtMin.setEnabled(false);
				txtIdPro.setVisible(true);
				txtInvAct.setEnabled(false);
				comboBox.setEnabled(false);
			
				txtMax.setText("");
				txtMin.setText("");
				txtInvAct.setText("");
				
				txtMax.setVisible(true);
				txtMin.setVisible(true);
				spinnerMax.setVisible(false);
				spinnerMax.setEnabled(false);
				spinnerMin.setVisible(false);
				spinnerMin.setEnabled(false);
				
				ShowPosInfo(0);
			}
		});
		btnCancelar.setBounds(495, 200, 135, 31);
		btnCancelar.setVisible(false);
		contentPane.add(btnCancelar);
		
		txtRegistro = new JTextField();
		txtRegistro.setFont(new Font("Tahoma", Font.BOLD, 13));
		txtRegistro.setEnabled(false);
		txtRegistro.setBounds(308, 268, 118, 28);
		contentPane.add(txtRegistro);
		txtRegistro.setColumns(10);
		
		lblModo = new JLabel("Modo: Lectura");
		lblModo.setBounds(406, 11, 130, 14);
		contentPane.add(lblModo);
		
		comboBox = new JComboBox();
		comboBox.setEnabled(false);
		comboBox.setBounds(142, 7, 145, 22);
		contentPane.add(comboBox);
		
		spinnerMax = new JSpinner();
		spinnerMax.setEnabled(false);
		spinnerMax.setVisible(false);
		spinnerMax.setModel(new SpinnerNumberModel(0, 0, 100, 1));
		spinnerMax.setBounds(142, 71, 46, 20);
		contentPane.add(spinnerMax);
		
		spinnerMin = new JSpinner();
		spinnerMin.setEnabled(false);
		spinnerMin.setVisible(false);
		spinnerMin.setModel(new SpinnerNumberModel(1, 1, 100, 1));
		spinnerMin.setBounds(142, 131, 46, 20);
		contentPane.add(spinnerMin);
		
		ShowPosInfo(0);
		mostrarProducto();
	}
	static Connection conexion() {
		 Connection con1;
		 try {
			    Class.forName("com.mysql.jdbc.Driver");
			    con1 = DriverManager.getConnection("jdbc:mysql://localhost/nota","root", "");			   
			    return con1;
			} catch (Exception e) {
				 JOptionPane.showMessageDialog(null, "Error en la conexion con la Base de datos", "Error en B.D" ,JOptionPane.ERROR_MESSAGE);
				 }return null;
	}
	
	void mostrarProducto(){
		Connection conec = conexion();
		String sql="SELECT * FROM productos";
		try{
		Statement st=conec.createStatement();
		ResultSet rs= st.executeQuery(sql);
		while(rs.next()){
		comboBox.addItem(rs.getString("Id_Producto") +".-" + rs.getString("Nombre"));
		comboBox.addItem(rs.getString("Id_Producto"));
		}
		
		}
		catch(Exception e){
			sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
 	        sonido.play();		
 			Icon ico=new ImageIcon(getClass().getResource("/Proyecto/icono.gif")); 
 			JOptionPane.showMessageDialog(null, "Llave foranea no conectada","",JOptionPane.ERROR_MESSAGE,ico);
		}
		}
	
	public static List<Inventario> BindList() {
		try {
			Connection con = conexion();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM  inventario ");
			List<Inventario> list = new ArrayList<Inventario>();
			while (rs.next()) {

				Inventario u = new Inventario(rs.getString("Id_Producto"), 
						Integer.parseInt(rs.getString("M�ximo")),
						Integer.parseInt(rs.getString("M�nimo")), 
						Integer.parseInt(rs.getString("Inventario_Actual")));

				list.add(u);
			}

			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;

	}

	public void ShowPosInfo(int index) {
		try {

			txtIdPro.setText(BindList().get(index).getId_Producto());
			txtMax.setText(Integer.toString(BindList().get(index).getMaximo()));
			txtMin.setText(Integer.toString(BindList().get(index).getMinimo()));
			txtInvAct.setText(Integer.toString(BindList().get(index).getInv_Act()));

			
			txtRegistro.setText("Registro # " + Integer.toString(pos + 1));
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "No registros en la bd", "", JOptionPane.ERROR_MESSAGE);
		}

	}
	
	
	
		
}
