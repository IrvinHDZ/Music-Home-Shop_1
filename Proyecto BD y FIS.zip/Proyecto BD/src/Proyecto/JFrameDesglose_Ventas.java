package Proyecto;

import java.applet.AudioClip;
import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.awt.event.ActionEvent;
import com.toedter.calendar.JDateChooser;
import java.awt.Toolkit;
import java.awt.Font;

public class JFrameDesglose_Ventas extends JFrame {
	int pos=0;
	public	AudioClip sonido;
	ResultSet rs;
	PreparedStatement ps;
	boolean modoAgregar=false,modoEliminar=false,modoModificar=false;
	private JPanel contentPane;
	private JTextField txtTotal;
	private JTextField txtCantidad;
	private JButton btnI;
	private JButton btnA;
	private JButton btnS;
	private JButton btnU;
	private JButton btnAgregar;
	private JButton btnModificar;
	private JButton btnEliminar;
	private JButton btnConfirmar;
	private JButton btnCancelar;
	private JTextField txtRegistro;
	private JLabel lblModo;
	private JComboBox comboBoxIdVen,comboBoxIdPro;
	private JTextField txtIdVen;
	private JTextField txtIdPro;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JFrameDesglose_Ventas frame = new JFrameDesglose_Ventas();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public JFrameDesglose_Ventas() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(JFrameDesglose_Ventas.class.getResource("/Imagenes/corbeille_box_sale_v.png")));
		Connection con = conexion();
		Icon ico = new ImageIcon(getClass().getResource("/Proyecto/icono.gif"));
		
		setTitle("Base de Datos del Desglose de Ventas");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 750, 340);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtIdPro = new JTextField();
		txtIdPro.setEnabled(false);
		txtIdPro.setColumns(10);
		txtIdPro.setBounds(142, 29, 190, 23);
		contentPane.add(txtIdPro);
		
		txtTotal = new JTextField();
		txtTotal.setEnabled(false);
		txtTotal.setBounds(142, 167, 190, 20);
		contentPane.add(txtTotal);
		txtTotal.setColumns(10);
		
		JLabel lblId = new JLabel("Id Producto: ");
		lblId.setBounds(10, 33, 122, 14);
		contentPane.add(lblId);
		
		JLabel lblIdVen = new JLabel("Id Ventas:");
		lblIdVen.setBounds(10, 76, 122, 14);
		contentPane.add(lblIdVen);
		
		JLabel lblTotal = new JLabel("Total:");
		lblTotal.setBounds(10, 173, 122, 14);
		contentPane.add(lblTotal);
		
		JLabel lblCan = new JLabel("Cantidad:");
		lblCan.setBounds(10, 121, 122, 14);
		contentPane.add(lblCan);
		
		txtCantidad = new JTextField();
		txtCantidad.setEnabled(false);
		txtCantidad.setBounds(142, 118, 190, 20);
		contentPane.add(txtCantidad);
		txtCantidad.setColumns(10);
		
		JButton btnSalir = new JButton(" Salir");
		btnSalir.setIcon(new ImageIcon(JFrameDesglose_Ventas.class.getResource("/Imagenes/stock_exit.png")));
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnSalir.setBounds(604, 226, 120, 31);
		contentPane.add(btnSalir);
		
		btnI = new JButton("Inicio");
		btnI.setIcon(new ImageIcon(JFrameDesglose_Ventas.class.getResource("/Imagenes/control_stop_left.png")));
		btnI.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pos = 0;
	            ShowPosInfo(pos);
			}
		});
		btnI.setBounds(10, 268, 139, 28);
		contentPane.add(btnI);
		
		btnA = new JButton("Anterior");
		btnA.setIcon(new ImageIcon(JFrameDesglose_Ventas.class.getResource("/Imagenes/control_double_left.png")));
		btnA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pos--;
	            if(pos >= 0){
	                ShowPosInfo(pos);                
	            }
	            else{
	            	if(pos < 0){
	            		sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
	                    sonido.play(); 
	            		JOptionPane.showMessageDialog(null, "Ya es el primer registro","",JOptionPane.ERROR_MESSAGE,ico);
		                    pos = 0;            
		            }
	                
	            }
				
			}
		});
		btnA.setBounds(159, 268, 139, 28);
		contentPane.add(btnA);
		
		btnS = new JButton("Siguiente");
		btnS.setIcon(new ImageIcon(JFrameDesglose_Ventas.class.getResource("/Imagenes/control_double_right.png")));
		btnS.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pos++;
	               if(pos < BindList().size()){
	                   ShowPosInfo(pos);
	               }
	               else{
	                   pos = BindList().size() - 1;
	                   ShowPosInfo(pos);
	                   sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
	                   sonido.play();
	           		JOptionPane.showMessageDialog(null, "Ya es el ultimo registro","",JOptionPane.ERROR_MESSAGE,ico);
	               }
			}
		});
		btnS.setBounds(436, 268, 139, 28);
		contentPane.add(btnS);
		
		btnU = new JButton("Ultimo");
		btnU.setIcon(new ImageIcon(JFrameDesglose_Ventas.class.getResource("/Imagenes/control_stop_right.png")));
		btnU.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pos = BindList().size() - 1;
				ShowPosInfo(pos);
			}
		});
		btnU.setBounds(585, 268, 139, 28);
		contentPane.add(btnU);
		
		btnAgregar = new JButton(" Agregar");
		btnAgregar.setIcon(new ImageIcon(JFrameDesglose_Ventas.class.getResource("/Imagenes/add.png")));
		btnAgregar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				modoAgregar = true;

				lblModo.setText("Modo: Agregar");

				comboBoxIdPro.setEnabled(true);
				txtCantidad.setEnabled(true);
				txtTotal.setEnabled(true);
				comboBoxIdVen.setEnabled(true);
				
				txtCantidad.setText("");
				txtTotal.setText("");

				comboBoxIdPro.setVisible(true);
				comboBoxIdVen.setVisible(true);
				btnAgregar.setVisible(false);
				txtRegistro.setVisible(false);
				lblId.setVisible(true);
				txtIdVen.setVisible(false);
				txtIdPro.setVisible(false);
				btnEliminar.setVisible(false);
				btnModificar.setVisible(false);
				btnSalir.setVisible(false);
				btnI.setVisible(false);
				btnS.setVisible(false);
				btnU.setVisible(false);
				btnA.setVisible(false);

				btnConfirmar.setVisible(true);
				btnCancelar.setVisible(true);
			}
		});
		btnAgregar.setBounds(10, 226, 120, 31);
		contentPane.add(btnAgregar);
		
		btnModificar = new JButton(" Modificar");
		btnModificar.setIcon(new ImageIcon(JFrameDesglose_Ventas.class.getResource("/Imagenes/refresh.png")));
		btnModificar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				comboBoxIdPro.setSelectedItem(txtIdPro.getText());
				comboBoxIdVen.setSelectedItem(txtIdVen.getText());
		
				modoModificar = true;
				
				lblModo.setText("Modo: Modificar");
				
				comboBoxIdPro.setEnabled(true);
				comboBoxIdVen.setEnabled(true);
				comboBoxIdVen.setVisible(true);
				txtCantidad.setEnabled(true);
				txtTotal.setEnabled(true);
				txtIdVen.setVisible(false);
				comboBoxIdPro.setVisible(true);
				txtRegistro.setVisible(false);
				btnAgregar.setVisible(false);
				lblId.setVisible(true);
				txtIdPro.setVisible(false);
				btnEliminar.setVisible(false);
				btnModificar.setVisible(false);
				btnSalir.setVisible(false);
				btnI.setVisible(false);
				btnS.setVisible(false);
				btnU.setVisible(false);
				btnA.setVisible(false);

				btnConfirmar.setVisible(true);
				btnCancelar.setVisible(true);
				
			}
		});
		btnModificar.setBounds(212, 226, 120, 31);
		contentPane.add(btnModificar);
		
		btnEliminar = new JButton(" Eliminar");
		btnEliminar.setIcon(new ImageIcon(JFrameDesglose_Ventas.class.getResource("/Imagenes/trash_can.png")));
		btnEliminar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				modoEliminar = true;
				lblModo.setText("Modo: Eliminar");

				btnAgregar.setVisible(false);
				txtRegistro.setVisible(false);
				btnEliminar.setVisible(false);
				btnModificar.setVisible(false);
				btnSalir.setVisible(false);
				btnI.setVisible(false);
				btnS.setVisible(false);
				btnU.setVisible(false);
				btnA.setVisible(false);

				btnConfirmar.setVisible(true);
				btnCancelar.setVisible(true);
			}
		});
		btnEliminar.setBounds(406, 226, 120, 31);
		contentPane.add(btnEliminar);
		
		btnConfirmar = new JButton(" Confirmar");
		btnConfirmar.setIcon(new ImageIcon(JFrameDesglose_Ventas.class.getResource("/Imagenes/tick_circle.png")));
		btnConfirmar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int confirmado = JOptionPane.showConfirmDialog(null,"Presione YES para confirmar. \nPresione NO para anular accion.","Confirmacion",JOptionPane.YES_NO_OPTION);
				if (JOptionPane.YES_OPTION == confirmado) {
					String total, cantidad, idven, idpro;
					if (modoAgregar == true) {
						
						
						cantidad = txtCantidad.getText();
						total = txtTotal.getText();
						
						idven=(String) comboBoxIdVen.getSelectedItem();
				 		
						
						
						
						
						idpro=(String) comboBoxIdPro.getSelectedItem();
				 		int j=0;
						String aux="";
						if(idpro.contains(".")) {
				 			while(idpro.charAt(j)!='.') {
				 			aux=aux+idpro.substring(j,(j+1));
				 			j++;
				 		}
				 			}else {
				 				aux=idpro;
				 			}
				 		

						Connection con = conexion();

						if (cantidad.isEmpty() || total.isEmpty()) {
							sonido = java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
							sonido.play();
							JOptionPane.showMessageDialog(null, "Error al momento de agregar", "",JOptionPane.ERROR_MESSAGE, ico);
						} else {
							String sqlInsert = "INSERT INTO desglose_ventas(`Id_Ventas`, `Id_Producto`, `Cantidad`, `Total`) VALUES ('"+ idven + "','"+ aux + "','" + cantidad + "','" + total + "')";
							try {
								Statement stmt = con.createStatement();
								stmt.executeUpdate(sqlInsert);
								JOptionPane.showMessageDialog(btnAgregar, "Se ha guardado el Registro", "Insertar",JOptionPane.INFORMATION_MESSAGE);

							} catch (Exception e1) {
								sonido = java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
								sonido.play();
								JOptionPane.showMessageDialog(null, "Error al agregar", "", JOptionPane.ERROR_MESSAGE, ico);
							}
						}
						modoAgregar = false;
						comboBoxIdVen.setEnabled(false);
						txtCantidad.setEnabled(false);
						txtTotal.setEnabled(false);
						comboBoxIdPro.setEnabled(false);

						txtCantidad.setText("");
						txtTotal.setText("");
						txtIdPro.setVisible(true);
						lblModo.setText("Modo: Lectura");
						lblId.setVisible(true);
						btnAgregar.setVisible(true);
						comboBoxIdPro.setVisible(true);
						txtRegistro.setVisible(true);
						btnEliminar.setVisible(true);
						btnModificar.setVisible(true);
						txtIdVen.setVisible(true);
						btnI.setVisible(true);
						btnS.setVisible(true);
						btnU.setVisible(true);
						btnA.setVisible(true);

						btnSalir.setVisible(true);

						btnConfirmar.setVisible(false);
						btnCancelar.setVisible(false);

						ShowPosInfo(0);
						}

					if (modoModificar == true) {

						cantidad = txtCantidad.getText();
						total = txtTotal.getText();
						
						idven=(String) comboBoxIdVen.getSelectedItem();
				 		
						
						idpro=(String) comboBoxIdPro.getSelectedItem();
				 		int j=0;
						String aux="";
						if(idpro.contains(".")) {
				 			while(idpro.charAt(j)!='.') {
				 			aux=aux+idpro.substring(j,(j+1));
				 			j++;
				 		}
				 			}else {
				 				aux=idpro;
				 			}
				 		
						Connection con = conexion();
					
						String sqlupdate = "UPDATE desglose_ventas SET `Id_Ventas`='"+ idven +"',`Id_Producto`='"+ aux +"',`Cantidad`='"+ cantidad +"',`Total`='"+ total +"' WHERE Id_Ventas = " + idven;
						 
						 if(cantidad.isEmpty() || total.isEmpty()) {
						 JOptionPane.showMessageDialog(null, "Error al momento de modificar :(","ERROR!!!" ,JOptionPane.ERROR_MESSAGE);
						sonido = java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
						sonido.play();
						Icon ico = new ImageIcon(getClass().getResource("/Proyecto/icono.gif"));
						JOptionPane.showMessageDialog(null, "Error al momento de modificar", "", JOptionPane.ERROR_MESSAGE,
								ico);
						 }else {
						try {
							Statement stmt = con.createStatement();
							 stmt.executeUpdate(sqlupdate);
							JOptionPane.showMessageDialog(btnAgregar, "Se han confirmado los cambios", "Modificar",
									JOptionPane.INFORMATION_MESSAGE);
						} catch (Exception e1) {
							sonido = java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
							sonido.play();
							JOptionPane.showMessageDialog(null, "Error al momento de modificar", "",
									JOptionPane.ERROR_MESSAGE, ico);
						}
						 }

						modoModificar = false;
						comboBoxIdVen.setEnabled(false);
						txtCantidad.setEnabled(false);
						txtTotal.setEnabled(false);
						comboBoxIdPro.setEnabled(false);
						txtIdPro.setVisible(true);
						txtCantidad.setText("");
						txtTotal.setText("");

						lblModo.setText("Modo: Lectura");
						lblId.setVisible(true);
						btnAgregar.setVisible(true);
						comboBoxIdPro.setVisible(true);
						txtRegistro.setVisible(true);
						btnEliminar.setVisible(true);
						btnModificar.setVisible(true);
						txtIdVen.setVisible(true);
						btnI.setVisible(true);
						btnS.setVisible(true);
						btnU.setVisible(true);
						btnA.setVisible(true);

						btnSalir.setVisible(true);

						btnConfirmar.setVisible(false);
						btnCancelar.setVisible(false);

						ShowPosInfo(pos);
					}
					if (modoEliminar == true) {
						
						idpro=(String) comboBoxIdPro.getSelectedItem();
				 		int j=0;
						String aux="";
						if(idpro.contains(".")) {
				 			while(idpro.charAt(j)!='.') {
				 			aux=aux+idpro.substring(j,(j+1));
				 			j++;
				 		}
				 			}else {
				 				aux=idpro;
				 			}
						
						idven=(String) comboBoxIdVen.getSelectedItem();
				 		
						
						
						
						 String SqlSt = "DELETE FROM desglose_ventas WHERE `Id_Ventas`= "+ idven +" AND `Id_Producto`= " + aux;
						Connection con = conexion();
						try {
							Statement stmt = con.createStatement();
							 stmt.executeUpdate(SqlSt);

							JOptionPane.showMessageDialog(btnEliminar, "Eliminacion Exitosa", "Eliminar",JOptionPane.INFORMATION_MESSAGE);
						} catch (Exception e1) {
							sonido = java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
							sonido.play();
							JOptionPane.showMessageDialog(null, "No se pudo eliminar", "", JOptionPane.ERROR_MESSAGE, ico);
						}
						modoEliminar=false;
						comboBoxIdVen.setEnabled(false);
						txtCantidad.setEnabled(false);
						txtTotal.setEnabled(false);
						comboBoxIdPro.setEnabled(false);

						txtCantidad.setText("");
						txtTotal.setText("");
						txtIdPro.setVisible(true);
						lblModo.setText("Modo: Lectura");
						lblId.setVisible(true);
						btnAgregar.setVisible(true);
						comboBoxIdPro.setVisible(true);
						txtRegistro.setVisible(true);
						txtIdVen.setVisible(true);
						btnEliminar.setVisible(true);
						btnModificar.setVisible(true);
						btnI.setVisible(true);
						btnS.setVisible(true);
						btnU.setVisible(true);
						btnA.setVisible(true);

						btnSalir.setVisible(true);

						btnConfirmar.setVisible(false);
						btnCancelar.setVisible(false);

						ShowPosInfo(0);
					}
				}
			}
		});
		btnConfirmar.setBounds(299, 198, 135, 31);
		btnConfirmar.setVisible(false);
		contentPane.add(btnConfirmar);
		
		btnCancelar = new JButton(" Cancelar");
		btnCancelar.setIcon(new ImageIcon(JFrameDesglose_Ventas.class.getResource("/Imagenes/no.png")));
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				modoAgregar = false;
				modoEliminar = false;
				modoModificar = false;

				comboBoxIdVen.setEnabled(false);
				txtCantidad.setEnabled(false);
				txtTotal.setEnabled(false);
				comboBoxIdPro.setEnabled(false);

				txtCantidad.setText("");
				txtTotal.setText("");

				lblModo.setText("Modo: Lectura");
				lblId.setVisible(true);
				btnAgregar.setVisible(true);
				comboBoxIdPro.setVisible(true);
				txtRegistro.setVisible(true);
				btnEliminar.setVisible(true);
				btnModificar.setVisible(true);
				btnI.setVisible(true);
				txtIdPro.setVisible(true);
				btnS.setVisible(true);
				btnU.setVisible(true);
				btnA.setVisible(true);
				txtIdVen.setVisible(true);
				btnSalir.setVisible(true);

				btnConfirmar.setVisible(false);
				btnCancelar.setVisible(false);

				ShowPosInfo(0);
				
			}
		});
		btnCancelar.setBounds(500, 198, 135, 31);
		btnCancelar.setVisible(false);
		contentPane.add(btnCancelar);
		
		txtRegistro = new JTextField();
		txtRegistro.setFont(new Font("Tahoma", Font.BOLD, 13));
		txtRegistro.setEnabled(false);
		txtRegistro.setBounds(308, 268, 118, 28);
		contentPane.add(txtRegistro);
		txtRegistro.setColumns(10);
		
		lblModo = new JLabel("Modo: Lectura");
		lblModo.setBounds(406, 11, 130, 14);
		contentPane.add(lblModo);
		
		comboBoxIdPro = new JComboBox();
		comboBoxIdPro.setEnabled(false);
		comboBoxIdPro.setBounds(142, 29, 190, 22);
		contentPane.add(comboBoxIdPro);
		
		txtIdVen = new JTextField();
		txtIdVen.setEnabled(false);
		txtIdVen.setColumns(10);
		txtIdVen.setBounds(142, 72, 190, 23);
		contentPane.add(txtIdVen);
		
		comboBoxIdVen = new JComboBox();
		comboBoxIdVen.setEnabled(false);
		comboBoxIdVen.setBounds(142, 72, 190, 22);
		contentPane.add(comboBoxIdVen);
		
		ShowPosInfo(0);
		mostrarProducto();
		mostrarVenta();
	}
	static Connection conexion() {
		 Connection con1;
		 try {
			    Class.forName("com.mysql.jdbc.Driver");
			    con1 = DriverManager.getConnection("jdbc:mysql://localhost/nota","root", "");			   
			    return con1;
			} catch (Exception e) {
				 JOptionPane.showMessageDialog(null, "Error en la conexion con la Base de datos", "Error en B.D" ,JOptionPane.ERROR_MESSAGE);
				 }return null;
	}
	
	void mostrarProducto(){
		Connection conec = conexion();
		String sql="SELECT * FROM productos";
		try{
		Statement st=conec.createStatement();
		ResultSet rs= st.executeQuery(sql);
		while(rs.next()){
		comboBoxIdPro.addItem(rs.getString("Id_Producto") +".-" + rs.getString("Nombre"));
		comboBoxIdPro.addItem(rs.getString("Id_Producto"));
		}
		
		}
		catch(Exception e){
			sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
 	        sonido.play();		
 			Icon ico=new ImageIcon(getClass().getResource("/Proyecto/icono.gif")); 
 			JOptionPane.showMessageDialog(null, "Llave foranea no conectada","",JOptionPane.ERROR_MESSAGE,ico);
		}
		}
	
	void mostrarVenta(){
		Connection conec = conexion();
		String sql="SELECT * FROM ventas";
		try{
		Statement st=conec.createStatement();
		ResultSet rs= st.executeQuery(sql);
		while(rs.next()){
		comboBoxIdVen.addItem(rs.getString("Id_Ventas"));
		}
		
		}
		catch(Exception e){
			sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
 	        sonido.play();		
 			Icon ico=new ImageIcon(getClass().getResource("/Proyecto/icono.gif")); 
 			JOptionPane.showMessageDialog(null, "Llave foranea no conectada","",JOptionPane.ERROR_MESSAGE,ico);
		}
		}
	

	public static List<Desgloce> BindList() {
		try {
			Connection con = conexion();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM  desglose_ventas ");
			List<Desgloce> list = new ArrayList<Desgloce>();
			while (rs.next()) {
				
				Desgloce u = new Desgloce(Integer.parseInt(rs.getString("Id_Producto")), 
						Integer.parseInt(rs.getString("Id_Ventas")),
						Integer.parseInt(rs.getString("Cantidad")), 
						Integer.parseInt(rs.getString("Total")));

				list.add(u);
			}

			return list;
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(null, "Listado no procesado" , "Insertar",JOptionPane.ERROR_MESSAGE);
		}
		return null;

	}

	public void ShowPosInfo(int index) {
		try {
			
			txtIdPro.setText(Integer.toString(BindList().get(index).getId_Producto()));
	        txtIdVen.setText(Integer.toString(BindList().get(index).getId_Ventas()));
			txtCantidad.setText(Integer.toString(BindList().get(index).getCantidad()));
			txtTotal.setText(Integer.toString(BindList().get(index).getTotal()));

			
			txtRegistro.setText("Registro # " + Integer.toString(pos + 1));
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "No registros en la bd", "", JOptionPane.ERROR_MESSAGE);
		}

	}
}
