package Proyecto;

import java.applet.AudioClip;
import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.awt.event.ActionEvent;
import com.toedter.calendar.JDateChooser;
import java.awt.Toolkit;
import java.awt.Font;

public class JFrameVenta extends JFrame {
	int pos=0;
	public	AudioClip sonido;
	ResultSet rs;
	PreparedStatement ps;
	boolean modoAgregar=false,modoEliminar=false,modoModificar=false;
	private JPanel contentPane;
	private JTextField txtId;
	private JTextField txtFecha;
	private JTextField txtTotal;
	private JButton btnI;
	private JButton btnA;
	private JButton btnS;
	private JButton btnU;
	private JButton btnAgregar;
	private JButton btnModificar;
	private JButton btnEliminar;
	private JButton btnConfirmar;
	private JButton btnCancelar;
	private JTextField txtRegistro;
	private JLabel lblModo;
	private JComboBox comboBox;
	private JDateChooser dateChooser;
	private JTextField txtTotalPro;
	private JTextField txtIdVen;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JFrameVenta frame = new JFrameVenta();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public JFrameVenta() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(JFrameVenta.class.getResource("/Imagenes/shopping_cart.png")));
		Connection con = conexion();
		Icon ico = new ImageIcon(getClass().getResource("/Proyecto/icono.gif"));
		
		setTitle("Base de Datos de las Ventas");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 750, 340);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtIdVen = new JTextField();
		txtIdVen.setEnabled(false);
		txtIdVen.setBounds(142, 45, 190, 22);
		contentPane.add(txtIdVen);
		txtIdVen.setColumns(10);
		
		txtFecha = new JTextField();
		txtFecha.setEnabled(false);
		txtFecha.setBounds(142, 130, 190, 20);
		contentPane.add(txtFecha);
		txtFecha.setColumns(10);
		
		JLabel lblId = new JLabel("Id Ventas: ");
		lblId.setBounds(10, 11, 122, 14);
		contentPane.add(lblId);
		
		txtId = new JTextField();
		txtId.setEnabled(false);
		txtId.setBounds(142, 8, 190, 20);
		contentPane.add(txtId);
		txtId.setColumns(10);
		
		JLabel lblCompa = new JLabel("Id Vendedor:");
		lblCompa.setBounds(10, 49, 122, 14);
		contentPane.add(lblCompa);
		
		JLabel lblDire = new JLabel("Fecha de venta:");
		lblDire.setBounds(10, 133, 122, 14);
		contentPane.add(lblDire);
		
		JLabel lblRfc = new JLabel("Total:");
		lblRfc.setBounds(10, 91, 122, 14);
		contentPane.add(lblRfc);
		
		txtTotal = new JTextField();
		txtTotal.setEnabled(false);
		txtTotal.setBounds(142, 88, 190, 20);
		contentPane.add(txtTotal);
		txtTotal.setColumns(10);
		
		JButton btnSalir = new JButton(" Salir");
		btnSalir.setIcon(new ImageIcon(JFrameVenta.class.getResource("/Imagenes/stock_exit.png")));
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnSalir.setBounds(604, 226, 120, 31);
		contentPane.add(btnSalir);
		
		btnI = new JButton("Inicio");
		btnI.setIcon(new ImageIcon(JFrameVenta.class.getResource("/Imagenes/control_stop_left.png")));
		btnI.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pos = 0;
	            ShowPosInfo(pos);
			}
		});
		btnI.setBounds(10, 268, 138, 28);
		contentPane.add(btnI);
		
		btnA = new JButton("Anterior");
		btnA.setIcon(new ImageIcon(JFrameVenta.class.getResource("/Imagenes/control_double_left.png")));
		btnA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pos--;
	            if(pos >= 0){
	                ShowPosInfo(pos);                
	            }
	            else{
	            	if(pos < 0){
	            		sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
	                    sonido.play(); 
	            		JOptionPane.showMessageDialog(null, "Ya es el primer registro","",JOptionPane.ERROR_MESSAGE,ico);
		                    pos = 0;            
		            }
	                
	            }
				
			}
		});
		btnA.setBounds(159, 268, 139, 28);
		contentPane.add(btnA);
		
		btnS = new JButton("Siguiente");
		btnS.setIcon(new ImageIcon(JFrameVenta.class.getResource("/Imagenes/control_double_right.png")));
		btnS.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pos++;
	               if(pos < BindList().size()){
	                   ShowPosInfo(pos);
	               }
	               else{
	                   pos = BindList().size() - 1;
	                   ShowPosInfo(pos);
	                   sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
	                   sonido.play();
	           		JOptionPane.showMessageDialog(null, "Ya es el ultimo registro","",JOptionPane.ERROR_MESSAGE,ico);
	               }
			}
		});
		btnS.setBounds(436, 268, 139, 28);
		contentPane.add(btnS);
		
		btnU = new JButton("Ultimo");
		btnU.setIcon(new ImageIcon(JFrameVenta.class.getResource("/Imagenes/control_stop_right.png")));
		btnU.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pos = BindList().size() - 1;
				ShowPosInfo(pos);
			}
		});
		btnU.setBounds(585, 268, 139, 28);
		contentPane.add(btnU);
		
		btnAgregar = new JButton(" Agregar");
		btnAgregar.setIcon(new ImageIcon(JFrameVenta.class.getResource("/Imagenes/add.png")));
		btnAgregar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				modoAgregar=true;
				
				dateChooser.setDate(null);
				
				lblModo.setText("Modo: Agregar");
				
				comboBox.setEnabled(true);
				txtTotal.setEnabled(true);
				txtId.setEnabled(true);
				txtTotalPro.setEnabled(true);
				dateChooser.setEnabled(true);

				txtTotal.setText("");
				txtId.setText("");
				txtTotalPro.setText("");

				comboBox.setVisible(true);
				dateChooser.setVisible(true);
				txtId.setVisible(false);
				lblId.setVisible(false);
				txtFecha.setVisible(false);
				txtIdVen.setVisible(false);
				btnAgregar.setVisible(false);
				txtRegistro.setVisible(false);
				btnEliminar.setVisible(false);
				btnModificar.setVisible(false);
				btnSalir.setVisible(false);
				btnI.setVisible(false);
				btnS.setVisible(false);
				btnU.setVisible(false);
				btnA.setVisible(false);

				btnConfirmar.setVisible(true);
				btnCancelar.setVisible(true);
				
			}
		});
		btnAgregar.setBounds(10, 226, 120, 31);
		contentPane.add(btnAgregar);
		
		btnModificar = new JButton(" Modificar");
		btnModificar.setIcon(new ImageIcon(JFrameVenta.class.getResource("/Imagenes/refresh.png")));
		btnModificar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				comboBox.setSelectedItem(txtIdVen.getText());
				
				try {
					int j=0;
					String an="",me="",di="";
					String ayuda=txtFecha.getText()+"-";
					while(ayuda.charAt(j)!='-') {
						an=an+ayuda.substring(j,j+1);
						j++;
					}
					while(ayuda.charAt(j+1)!='-') {
						me=me+ayuda.substring(j+1,j+2);
						j++;
					}		
					
					while(ayuda.charAt(j+2)!='-') {
						di=di+ayuda.substring((j+2),(j+3));
						j++;
					}
					String fechaact=an+"-"+me+"-"+di;
					SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
					try {
						Date date= formatter.parse(fechaact);
						dateChooser.setDate(date);
					} catch (Exception e2) {
						
						JOptionPane.showMessageDialog(btnAgregar, "Fecha NO cambiada", "Modificar",JOptionPane.INFORMATION_MESSAGE);
					}
					
				}catch(Exception error) {
					
				}
				
				
				
				modoModificar = true;
				
				lblModo.setText("Modo: Modificar");
				
				comboBox.setEnabled(true);
				txtTotal.setEnabled(true);
				txtId.setEnabled(true);
				txtTotalPro.setEnabled(true);
				dateChooser.setEnabled(true);

				txtId.setVisible(false);
				comboBox.setVisible(true);
				txtRegistro.setVisible(false);
				txtIdVen.setVisible(false);
				btnAgregar.setVisible(false);
				dateChooser.setVisible(true);
				lblId.setVisible(false);
				txtFecha.setVisible(false);
				btnEliminar.setVisible(false);
				btnModificar.setVisible(false);
				btnSalir.setVisible(false);
				btnI.setVisible(false);
				btnS.setVisible(false);
				btnU.setVisible(false);
				btnA.setVisible(false);

				btnConfirmar.setVisible(true);
				btnCancelar.setVisible(true);
				
			}
		});
		btnModificar.setBounds(212, 226, 120, 31);
		contentPane.add(btnModificar);
		
		btnEliminar = new JButton(" Eliminar");
		btnEliminar.setIcon(new ImageIcon(JFrameVenta.class.getResource("/Imagenes/trash_can.png")));
		btnEliminar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				modoEliminar=true;
				
				lblModo.setText("Modo: Eliminar");
				
				btnAgregar.setVisible(false);
				btnModificar.setVisible(false);
				btnEliminar.setVisible(false);
				btnSalir.setVisible(false);
				btnI.setVisible(false);
				btnA.setVisible(false);
				btnS.setVisible(false);
				btnU.setVisible(false);
				txtRegistro.setVisible(false);
				
				btnCancelar.setVisible(true);
				btnConfirmar.setVisible(true);
				
				
			}
		});
		btnEliminar.setBounds(406, 226, 120, 31);
		contentPane.add(btnEliminar);
		
		btnConfirmar = new JButton(" Confirmar");
		btnConfirmar.setIcon(new ImageIcon(JFrameVenta.class.getResource("/Imagenes/tick_circle.png")));
		btnConfirmar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int confirmado = JOptionPane.showConfirmDialog(null,"Presione YES para confirmar. \nPresione NO para anular accion.","Confirmacion",JOptionPane.YES_NO_OPTION);

				if (JOptionPane.YES_OPTION == confirmado) {
			
				String idven, total,totalpro, fecha, id;
				
				if (modoAgregar == true) {
					
					//Adaptar la fecha al gestor
					String dia="00";String mes="00";String year="0000";
					try {
					dia= Integer.toString(dateChooser.getCalendar().get(Calendar.DAY_OF_MONTH));
					mes= Integer.toString(dateChooser.getCalendar().get(Calendar.MONTH) + 1);
					year=Integer.toString(dateChooser.getCalendar().get(Calendar.YEAR));
					
					}catch(Exception error) {
					}
					
					fecha=year+"-"+mes+"-"+dia;
					
					total = txtTotal.getText();
					totalpro=txtTotalPro.getText();
					
					idven=(String) comboBox.getSelectedItem();
			 		int i=0;
					String aux="";
					if(idven.contains(".")) {
			 			while(idven.charAt(i)!='.') {
			 			aux=aux+idven.substring(i,(i+1));
			 			i++;
			 		}
			 			}else {
			 				aux=idven;
			 			}
			 		

					Connection con = conexion();
					
					if (total.isEmpty() || fecha=="000-00-00"|| totalpro.isEmpty()) {
						sonido = java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
						sonido.play();
						JOptionPane.showMessageDialog(null, "Error al momento de agregar", "",JOptionPane.ERROR_MESSAGE, ico);
					} else {
						String sqlInsert = "INSERT INTO ventas(`Fecha_Ventas`, `Total`, `Total_Productos`, `Id_Vendedor`) values ('"+ fecha + "','"+ total + "','" + totalpro + "','" + aux + "')";
						try {
							Statement stmt = con.createStatement();
							stmt.executeUpdate(sqlInsert);
							JOptionPane.showMessageDialog(btnAgregar, "Se ha guardado el Registro", "Insertar",JOptionPane.INFORMATION_MESSAGE);

						} catch (Exception e1) {
							sonido = java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
							sonido.play();
							JOptionPane.showMessageDialog(null, "Error al agregar", "", JOptionPane.ERROR_MESSAGE, ico);
						}
					}
					modoAgregar = false;
					txtTotal.setEnabled(false);
					txtId.setEnabled(false);
					comboBox.setEnabled(false);
					txtTotalPro.setEnabled(false);
					dateChooser.setEnabled(false);

					txtTotal.setText("");
					txtId.setText("");
					txtFecha.setText("");
					txtTotalPro.setText("");
					dateChooser.setDate(null);
					txtIdVen.setVisible(true);
					txtRegistro.setVisible(true);
					lblModo.setText("Modo: Lectura");
					lblId.setVisible(true);
					txtId.setVisible(true);
					dateChooser.setVisible(false);
					btnAgregar.setVisible(true);
					comboBox.setVisible(true);
					lblId.setVisible(true);
					txtFecha.setVisible(true);
					btnEliminar.setVisible(true);
					btnModificar.setVisible(true);
					btnI.setVisible(true);
					btnS.setVisible(true);
					btnU.setVisible(true);
					btnA.setVisible(true);

					btnSalir.setVisible(true);

					btnConfirmar.setVisible(false);
					btnCancelar.setVisible(false);


					ShowPosInfo(0);
					
				}

				if (modoModificar == true) {					
					
					//Adaptar la fecha al gestor
					String dia="00";String mes="00";String year="0000";
					try {
					dia= Integer.toString(dateChooser.getCalendar().get(Calendar.DAY_OF_MONTH));
					mes= Integer.toString(dateChooser.getCalendar().get(Calendar.MONTH) + 1);
					year=Integer.toString(dateChooser.getCalendar().get(Calendar.YEAR));
					}catch(Exception error) {
					}
					
					fecha=year+"-"+mes+"-"+dia;
					
					total = txtTotal.getText();
					id=txtId.getText();
					totalpro
					= txtTotalPro.getText();
					
					idven=(String) comboBox.getSelectedItem();
			 		int i=0;
					String aux="";
					if(idven.contains(".")) {
			 			while(idven.charAt(i)!='.') {
			 			aux=aux+idven.substring(i,(i+1));
			 			i++;
			 		}
			 			}else {
			 				aux=idven;
			 			}

					Connection con = conexion();
					
					String sqlupdate = "UPDATE ventas SET `Id_Ventas`='"+ id +"',`Fecha_Ventas`='"+ fecha +"',`Total`='"+ total +"',`Total_Productos`='"+ totalpro +"',`Id_Vendedor`='"+ aux +"' WHERE Id_Ventas = " + id;
					 
					 if(total.isEmpty() || fecha=="000-00-00"|| totalpro.isEmpty()) {
					 JOptionPane.showMessageDialog(null, "Error al momento de modificar :(","ERROR!!!" ,JOptionPane.ERROR_MESSAGE);
					sonido = java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
					sonido.play();
					Icon ico = new ImageIcon(getClass().getResource("/Proyecto/icono.gif"));
					JOptionPane.showMessageDialog(null, "Error al momento de modificar", "", JOptionPane.ERROR_MESSAGE,
							ico);
					 }else {
					try {
						Statement stmt = con.createStatement();
						 stmt.executeUpdate(sqlupdate);
						JOptionPane.showMessageDialog(btnAgregar, "Se han confirmado los cambios", "Modificar",JOptionPane.INFORMATION_MESSAGE);
					} catch (Exception e1) {
						sonido = java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
						sonido.play();
						JOptionPane.showMessageDialog(null, "Error al momento de modificar", "",
								JOptionPane.ERROR_MESSAGE, ico);
					}
					 }

					modoModificar = false;
					txtTotal.setEnabled(false);
					txtId.setEnabled(false);
					txtTotalPro.setEnabled(false);
					comboBox.setEnabled(false);
					dateChooser.setEnabled(false);

					dateChooser.setDate(null);
					txtIdVen.setVisible(true);
					txtRegistro.setVisible(true);
					lblModo.setText("Modo: Lectura");
					lblId.setVisible(true);
					btnAgregar.setVisible(true);
					txtId.setVisible(true);
					lblId.setVisible(true);
					comboBox.setVisible(true);
					dateChooser.setVisible(false);
					btnEliminar.setVisible(true);
					btnModificar.setVisible(true);
					txtFecha.setVisible(true);
					btnI.setVisible(true);
					btnS.setVisible(true);
					btnU.setVisible(true);
					btnA.setVisible(true);

					btnSalir.setVisible(true);

					btnConfirmar.setVisible(false);
					btnCancelar.setVisible(false);
					
					ShowPosInfo(pos);
					
				}
				if (modoEliminar == true) {
					
					id=txtId.getText();
					
					 String SqlSt = "DELETE FROM ventas WHERE Id_Ventas= "+ id;
					Connection con = conexion();
					try {
						Statement stmt = con.createStatement();
						 stmt.executeUpdate(SqlSt);

						JOptionPane.showMessageDialog(btnEliminar, "Eliminacion Exitosa", "Eliminar",JOptionPane.INFORMATION_MESSAGE);
					} catch (Exception e1) {
						sonido = java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
						sonido.play();
						JOptionPane.showMessageDialog(null, "No se pudo eliminar", "", JOptionPane.ERROR_MESSAGE, ico);
					}
					
					modoEliminar = false;
					txtTotal.setEnabled(false);
					txtId.setEnabled(false);
					comboBox.setEnabled(false);
					dateChooser.setEnabled(false);
					txtTotalPro.setEnabled(false);
					txtIdVen.setVisible(true);
					txtTotal.setText("");
					txtId.setText("");
					txtFecha.setText("");
					txtTotalPro.setText("");
					dateChooser.setDate(null);
					
					txtRegistro.setVisible(true);
					lblModo.setText("Modo: Lectura");
					lblId.setVisible(true);
					btnAgregar.setVisible(true);
					comboBox.setVisible(true);
					dateChooser.setVisible(false);
					lblId.setVisible(true);
					btnEliminar.setVisible(true);
					txtId.setVisible(true);
					btnModificar.setVisible(true);
					btnI.setVisible(true);
					btnS.setVisible(true);
					txtFecha.setVisible(true);
					btnU.setVisible(true);
					btnA.setVisible(true);

					btnSalir.setVisible(true);

					btnConfirmar.setVisible(false);
					btnCancelar.setVisible(false);
					
					ShowPosInfo(0);
				}
			}
		}
		});
		btnConfirmar.setBounds(308, 196, 135, 31);
		btnConfirmar.setVisible(false);
		contentPane.add(btnConfirmar);
		
		btnCancelar = new JButton(" Cancelar");
		btnCancelar.setIcon(new ImageIcon(JFrameVenta.class.getResource("/Imagenes/no.png")));
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				modoAgregar=false;
				modoEliminar=false;
				modoModificar=false;
				
				txtTotal.setEnabled(false);
				txtId.setEnabled(false);
				comboBox.setEnabled(false);
				txtTotalPro.setEnabled(false);
				dateChooser.setEnabled(false);

				dateChooser.setDate(null);

				txtId.setVisible(true);
				lblModo.setText("Modo: Lectura");
				lblId.setVisible(true);
				lblId.setVisible(true);
				btnAgregar.setVisible(true);
				comboBox.setVisible(true);
				txtIdVen.setVisible(true);
				dateChooser.setVisible(false);
				txtFecha.setVisible(true);
				txtRegistro.setVisible(true);
				btnEliminar.setVisible(true);
				btnModificar.setVisible(true);
				btnI.setVisible(true);
				btnS.setVisible(true);
				btnU.setVisible(true);
				btnA.setVisible(true);

				btnSalir.setVisible(true);

				btnConfirmar.setVisible(false);
				btnCancelar.setVisible(false);
				ShowPosInfo(0);
							
			}
		});
		btnCancelar.setBounds(493, 196, 135, 31);
		btnCancelar.setVisible(false);
		contentPane.add(btnCancelar);
		
		txtRegistro = new JTextField();
		txtRegistro.setFont(new Font("Tahoma", Font.BOLD, 13));
		txtRegistro.setEnabled(false);
		txtRegistro.setBounds(308, 268, 118, 28);
		contentPane.add(txtRegistro);
		txtRegistro.setColumns(10);
		
		lblModo = new JLabel("Modo: Lectura");
		lblModo.setBounds(406, 11, 130, 14);
		contentPane.add(lblModo);
		
		dateChooser = new JDateChooser();
		dateChooser.setBounds(142, 130, 190, 20);
		dateChooser.setDateFormatString("yyyy-MM-dd");
		dateChooser.setVisible(false);
		dateChooser.setEnabled(false);
		contentPane.add(dateChooser);
		
		comboBox = new JComboBox();
		comboBox.setEnabled(false);
		comboBox.setBounds(142, 45, 190, 22);
		contentPane.add(comboBox);
		
		JLabel lblTotalDeProductos = new JLabel("Total de Productos:");
		lblTotalDeProductos.setBounds(10, 176, 122, 14);
		contentPane.add(lblTotalDeProductos);
		
		txtTotalPro = new JTextField();
		txtTotalPro.setEnabled(false);
		txtTotalPro.setBounds(142, 173, 190, 20);
		contentPane.add(txtTotalPro);
		txtTotalPro.setColumns(10);
		
		ShowPosInfo(0);
		mostrarVendedor();
	}
	static Connection conexion() {
		 Connection con1;
		 try {
			    Class.forName("com.mysql.jdbc.Driver");
			    con1 = DriverManager.getConnection("jdbc:mysql://localhost/nota","root", "");			   
			    return con1;
			} catch (Exception e) {
				 JOptionPane.showMessageDialog(null, "Error en la conexion con la Base de datos", "Error en B.D" ,JOptionPane.ERROR_MESSAGE);
				 }return null;
	}
	
	void mostrarVendedor(){
		Connection conec = conexion();
		String sql="SELECT * FROM vendedor";
		try{
		Statement st=conec.createStatement();
		ResultSet rs= st.executeQuery(sql);
		while(rs.next()){
		comboBox.addItem(rs.getString("Id_Vendedor") +".-" + rs.getString("Nombre(s)"));
		comboBox.addItem(rs.getString("Id_Vendedor"));
		}
		
		}
		catch(Exception e){
			sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
 	        sonido.play();		
 			Icon ico=new ImageIcon(getClass().getResource("/Proyecto/icono.gif")); 
 			JOptionPane.showMessageDialog(null, "Llave foranea no conectada","",JOptionPane.ERROR_MESSAGE,ico);
		}
		}

	public static List<Ventas> BindList() {
		try {
			Connection con = conexion();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM  ventas ");
			List<Ventas> list = new ArrayList<Ventas>();
			while (rs.next()) {

				Ventas u = new Ventas(Integer.parseInt(rs.getString("Id_Ventas")), 
						Integer.parseInt(rs.getString("Total")),
						Integer.parseInt(rs.getString("Total_Productos")),
						rs.getString("Fecha_Ventas"), 
						rs.getString("Id_Vendedor")
						);

				list.add(u);
			}

			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;

	}

	public void ShowPosInfo(int index) {
		try {
			
	        txtIdVen.setText(BindList().get(index).getIdVendedor());
			txtTotal.setText(Integer.toString(BindList().get(index).getTotal()));
			txtId.setText(Integer.toString(BindList().get(index).getId()));
			txtFecha.setText(BindList().get(index).getFecha());
			txtTotalPro.setText(Integer.toString(BindList().get(index).getTotal_Productos()));

			
			txtRegistro.setText("Registro # " + Integer.toString(pos + 1));
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "No registros en la bd", "", JOptionPane.ERROR_MESSAGE);
		}

	}
}
