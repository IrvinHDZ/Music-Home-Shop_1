package Proyecto;
public class Producto {
private int Id,Cantidad;
private String Nombre,Descripcion,Categoria,Marca,Ruta,Compa�ia,Id_Proveedor;
private double Precio;
private String Activado;

public Producto(int id, int cantidad, String id_Proveedor, String nombre, String descripcion, String categoria,
		String marca, String ruta,  double precio, String activado) {
	Id = id;
	Cantidad = cantidad;
	Id_Proveedor = id_Proveedor;
	Nombre = nombre;
	Descripcion = descripcion;
	Categoria = categoria;
	Marca = marca;
	Ruta = ruta;
	Precio = precio;
	Activado = activado;
}
public Producto() {
	
}


public int getId() {
	return Id;
}
public void setId(int id) {
	Id = id;
}
public int getCantidad() {
	return Cantidad;
}
public void setCantidad(int cantidad) {
	Cantidad = cantidad;
}
public String getId_Proveedor() {
	return Id_Proveedor;
}
public void setId_Proveedor(String id_Proveedor) {
	Id_Proveedor = id_Proveedor;
}
public String getNombre() {
	return Nombre;
}
public void setNombre(String nombre) {
	Nombre = nombre;
}
public String getDescripcion() {
	return Descripcion;
}
public void setDescripcion(String descripcion) {
	Descripcion = descripcion;
}
public String getCategoria() {
	return Categoria;
}
public void setCategoria(String categoria) {
	Categoria = categoria;
}
public String getMarca() {
	return Marca;
}
public void setMarca(String marca) {
	Marca = marca;
}
public String getRuta() {
	return Ruta;
}
public void setRuta(String ruta) {
	Ruta = ruta;
}
public double getPrecio() {
	return Precio;
}
public void setPrecio(double precio) {
	Precio = precio;
}

public String getActivado() {
	return Activado;
}
public void setActivado(String activado) {
	Activado = activado;
}


}
