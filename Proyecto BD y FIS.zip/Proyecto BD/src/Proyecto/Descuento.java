package Proyecto;

public class Descuento {
private String Id_Producto, Fecha;
private int Id,Porcentaje;
public Descuento(String id_Producto, String fecha, int id, int porcentaje) {
	Id_Producto = id_Producto;
	Fecha = fecha;
	Id = id;
	Porcentaje = porcentaje;
}
public String getId_Producto() {
	return Id_Producto;
}
public void setId_Producto(String id_Producto) {
	Id_Producto = id_Producto;
}
public String getFecha() {
	return Fecha;
}
public void setFecha(String fecha) {
	Fecha = fecha;
}
public int getId() {
	return Id;
}
public void setId(int id) {
	Id = id;
}
public int getPorcentaje() {
	return Porcentaje;
}
public void setPorcentaje(int porcentaje) {
	Porcentaje = porcentaje;
}

}
