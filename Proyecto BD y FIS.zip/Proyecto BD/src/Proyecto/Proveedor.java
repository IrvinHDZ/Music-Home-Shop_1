package Proyecto;

public class Proveedor {
	private int Id;
	private String Compa�ia, RFC, Direccion, Telefono;
	public Proveedor(int id, String compa�ia, String rFC, String direccion, String telefono) {
		Id = id;
		Compa�ia = compa�ia;
		RFC = rFC;
		Direccion = direccion;
		Telefono = telefono;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getCompa�ia() {
		return Compa�ia;
	}
	public void setCompa�ia(String compa�ia) {
		Compa�ia = compa�ia;
	}
	public String getRFC() {
		return RFC;
	}
	public void setRFC(String rFC) {
		RFC = rFC;
	}
	public String getDireccion() {
		return Direccion;
	}
	public void setDireccion(String direccion) {
		Direccion = direccion;
	}
	public String getTelefono() {
		return Telefono;
	}
	public void setTelefono(String telefono) {
		Telefono = telefono;
	}
	

}
