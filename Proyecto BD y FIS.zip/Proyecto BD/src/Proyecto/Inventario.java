package Proyecto;

public class Inventario {
	private int Maximo,Minimo,Inv_Act;
	private String Id_Producto;

	public Inventario(String id_Producto, int maximo, int minimo, int inv_Act) {
		Id_Producto = id_Producto;
		Maximo = maximo;
		Minimo = minimo;
		Inv_Act = inv_Act;
	}

	public String getId_Producto() {
		return Id_Producto;
	}

	public void setId_Producto(String id_Producto) {
		Id_Producto = id_Producto;
	}

	public int getMaximo() {
		return Maximo;
	}

	public void setMaximo(int maximo) {
		Maximo = maximo;
	}

	public int getMinimo() {
		return Minimo;
	}

	public void setMinimo(int minimo) {
		Minimo = minimo;
	}

	public int getInv_Act() {
		return Inv_Act;
	}

	public void setInv_Act(int inv_Act) {
		Inv_Act = inv_Act;
	}
	

}
