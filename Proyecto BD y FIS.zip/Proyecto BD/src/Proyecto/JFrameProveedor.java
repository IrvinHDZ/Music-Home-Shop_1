package Proyecto;

import java.applet.AudioClip;
import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;
import java.awt.Font;

public class JFrameProveedor extends JFrame {
	int pos=0;
	public	AudioClip sonido;
	ResultSet rs;
	PreparedStatement ps;
	boolean modoAgregar=false,modoEliminar=false,modoModificar=false;
	private JPanel contentPane;
	private JTextField txtId;
	private JTextField txtCompa;
	private JTextField txtDire;
	private JTextField txtRfc;
	private JTextField txtTel;
	private JButton btnI;
	private JButton btnA;
	private JButton btnS;
	private JButton btnU;
	private JButton btnAgregar;
	private JButton btnModificar;
	private JButton btnEliminar;
	private JButton btnConfirmar;
	private JButton btnCancelar;
	private JTextField txtRegistro;
	private JLabel lblModo;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JFrameProveedor frame = new JFrameProveedor();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public JFrameProveedor() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(JFrameProveedor.class.getResource("/Imagenes/customer_service.png")));
		Connection con = conexion();
		Icon ico = new ImageIcon(getClass().getResource("/Proyecto/icono.gif"));
		
		setTitle("Base de Datos de los Proveedores");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 750, 340);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblId = new JLabel("Id Proveedor: ");
		lblId.setBounds(10, 11, 122, 14);
		contentPane.add(lblId);
		
		txtId = new JTextField();
		txtId.setEnabled(false);
		txtId.setBounds(142, 8, 190, 20);
		contentPane.add(txtId);
		txtId.setColumns(10);
		
		JLabel lblCompa = new JLabel("Compa\u00F1ia:");
		lblCompa.setBounds(10, 51, 122, 14);
		contentPane.add(lblCompa);
		
		txtCompa = new JTextField();
		txtCompa.setEnabled(false);
		txtCompa.setBounds(142, 51, 190, 20);
		contentPane.add(txtCompa);
		txtCompa.setColumns(10);
		
		JLabel lblDire = new JLabel("Direccion:");
		lblDire.setBounds(10, 128, 122, 14);
		contentPane.add(lblDire);
		
		txtDire = new JTextField();
		txtDire.setEnabled(false);
		txtDire.setBounds(142, 125, 190, 20);
		contentPane.add(txtDire);
		txtDire.setColumns(10);
		
		JLabel lblRfc = new JLabel("RFC:");
		lblRfc.setBounds(10, 89, 122, 14);
		contentPane.add(lblRfc);
		
		txtRfc = new JTextField();
		txtRfc.setEnabled(false);
		txtRfc.setBounds(142, 86, 190, 20);
		contentPane.add(txtRfc);
		txtRfc.setColumns(10);
		
		JLabel lblTel = new JLabel("Telefono:");
		lblTel.setBounds(10, 163, 122, 14);
		contentPane.add(lblTel);
		
		txtTel = new JTextField();
		txtTel.setEnabled(false);
		txtTel.setBounds(142, 160, 190, 20);
		contentPane.add(txtTel);
		txtTel.setColumns(10);
		
		JButton btnSalir = new JButton(" Salir");
		btnSalir.setIcon(new ImageIcon(JFrameProveedor.class.getResource("/Imagenes/stock_exit.png")));
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnSalir.setBounds(604, 226, 120, 31);
		contentPane.add(btnSalir);
		
		btnI = new JButton("Inicio");
		btnI.setIcon(new ImageIcon(JFrameProveedor.class.getResource("/Imagenes/control_stop_left.png")));
		btnI.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pos = 0;
	            ShowPosInfo(pos);
			}
		});
		btnI.setBounds(10, 268, 139, 28);
		contentPane.add(btnI);
		
		btnA = new JButton("Anterior");
		btnA.setIcon(new ImageIcon(JFrameProveedor.class.getResource("/Imagenes/control_double_left.png")));
		btnA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pos--;
	            if(pos >= 0){
	                ShowPosInfo(pos);                
	            }
	            else{
	            	if(pos < 0){
	            		sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
	                    sonido.play(); 
	            		JOptionPane.showMessageDialog(null, "Ya es el primer registro","",JOptionPane.ERROR_MESSAGE,ico);
		                    pos = 0;            
		            }
	                
	            }
				
			}
		});
		btnA.setBounds(159, 268, 139, 28);
		contentPane.add(btnA);
		
		btnS = new JButton("Siguiente");
		btnS.setIcon(new ImageIcon(JFrameProveedor.class.getResource("/Imagenes/control_double_right.png")));
		btnS.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pos++;
	               if(pos < BindList().size()){
	                   ShowPosInfo(pos);
	               }
	               else{
	                   pos = BindList().size() - 1;
	                   ShowPosInfo(pos);
	                   sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
	                   sonido.play();
	           		JOptionPane.showMessageDialog(null, "Ya es el ultimo registro","",JOptionPane.ERROR_MESSAGE,ico);
	               }
			}
		});
		btnS.setBounds(436, 268, 139, 28);
		contentPane.add(btnS);
		
		btnU = new JButton("Ultimo");
		btnU.setIcon(new ImageIcon(JFrameProveedor.class.getResource("/Imagenes/control_stop_right.png")));
		btnU.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pos = BindList().size() - 1;
				ShowPosInfo(pos);
			}
		});
		btnU.setBounds(585, 268, 139, 28);
		contentPane.add(btnU);
		
		btnAgregar = new JButton(" Agregar");
		btnAgregar.setIcon(new ImageIcon(JFrameProveedor.class.getResource("/Imagenes/add.png")));
		btnAgregar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				modoAgregar=true;
				
				lblModo.setText("Modo: Agregar");
				
				lblId.setVisible(false);
				txtId.setVisible(false);
				btnAgregar.setVisible(false);
				btnModificar.setVisible(false);
				btnEliminar.setVisible(false);
				btnSalir.setVisible(false);
				btnI.setVisible(false);
				btnA.setVisible(false);
				btnS.setVisible(false);
				btnU.setVisible(false);
				txtRegistro.setVisible(false);
				
				btnCancelar.setVisible(true);
				btnConfirmar.setVisible(true);
				
				txtCompa.setEnabled(true);
				txtRfc.setEnabled(true);
				txtTel.setEnabled(true);
				txtDire.setEnabled(true);
				
				txtId.setText("");
				txtCompa.setText("");
				txtRfc.setText("");
				txtTel.setText("");
				txtDire.setText("");
				
			}
		});
		btnAgregar.setBounds(10, 226, 120, 31);
		contentPane.add(btnAgregar);
		
		btnModificar = new JButton(" Modificar");
		btnModificar.setIcon(new ImageIcon(JFrameProveedor.class.getResource("/Imagenes/refresh.png")));
		btnModificar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				modoModificar=true;
				
				lblModo.setText("Modo: Modificar");
				
				lblId.setVisible(false);
				txtId.setVisible(false);
				btnAgregar.setVisible(false);
				btnModificar.setVisible(false);
				btnEliminar.setVisible(false);
				btnSalir.setVisible(false);
				btnI.setVisible(false);
				btnA.setVisible(false);
				btnS.setVisible(false);
				btnU.setVisible(false);
				txtRegistro.setVisible(false);
				
				btnCancelar.setVisible(true);
				btnConfirmar.setVisible(true);
				
				txtCompa.setEnabled(true);
				txtRfc.setEnabled(true);
				txtTel.setEnabled(true);
				txtDire.setEnabled(true);
				
			}
		});
		btnModificar.setBounds(212, 226, 120, 31);
		contentPane.add(btnModificar);
		
		btnEliminar = new JButton(" Eliminar");
		btnEliminar.setIcon(new ImageIcon(JFrameProveedor.class.getResource("/Imagenes/trash_can.png")));
		btnEliminar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				modoEliminar=true;
				
				lblModo.setText("Modo: Eliminar");
				
				btnAgregar.setVisible(false);
				btnModificar.setVisible(false);
				btnEliminar.setVisible(false);
				btnSalir.setVisible(false);
				btnI.setVisible(false);
				btnA.setVisible(false);
				btnS.setVisible(false);
				btnU.setVisible(false);
				txtRegistro.setVisible(false);
				
				btnCancelar.setVisible(true);
				btnConfirmar.setVisible(true);
				
				
			}
		});
		btnEliminar.setBounds(406, 226, 120, 31);
		contentPane.add(btnEliminar);
		
		btnConfirmar = new JButton(" Confirmar");
		btnConfirmar.setIcon(new ImageIcon(JFrameProveedor.class.getResource("/Imagenes/tick_circle.png")));
		btnConfirmar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int confirmado = JOptionPane.showConfirmDialog(null,"Presione YES para confirmar. \nPresione NO para anular accion.","Confirmacion",JOptionPane.YES_NO_OPTION);

				if (JOptionPane.YES_OPTION == confirmado) {
					
				String compa�ia, rfc,direccion,telefono,id;
				if(modoAgregar==true) {
					
					compa�ia=txtCompa.getText();
					rfc=txtRfc.getText();
					direccion=txtDire.getText();
					telefono=txtTel.getText();
					
					Connection con = conexion();
					if(compa�ia.isEmpty() || telefono.isEmpty()) {
						sonido = java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
						sonido.play();
						JOptionPane.showMessageDialog(null, "Ya es el primer registro", "", JOptionPane.ERROR_MESSAGE,ico);
			 		}else {
			 			  String sqlInsert= "INSERT INTO proveedor(Compa�ia,RFC,Direccion,Telefono) values ('"+compa�ia+"','"+rfc+"','"+direccion+"','"+telefono+"')";
			 		try {
			 		Statement stmt = con.createStatement();
	 	            stmt.executeUpdate(sqlInsert);
	 	           JOptionPane.showMessageDialog(btnAgregar, "Se ha guardado el Registro" , "Insertar",JOptionPane.INFORMATION_MESSAGE);
	 	          
	 	        } catch (Exception e1) {
	 	        	sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
	 	           sonido.play();		
	 	   		Icon ico=new ImageIcon(getClass().getResource("/Proyecto/icono.gif")); 
	 	   		JOptionPane.showMessageDialog(null, "Error al agregar","",JOptionPane.ERROR_MESSAGE,ico);
	 	        }
			 		}
					
					modoAgregar=false;
					
					lblModo.setText("Modo: Lectura");
					
					lblId.setVisible(true);
					txtId.setVisible(true);
					btnAgregar.setVisible(true);
					btnModificar.setVisible(true);
					btnEliminar.setVisible(true);
					btnSalir.setVisible(true);
					btnI.setVisible(true);
					btnA.setVisible(true);
					btnS.setVisible(true);
					btnU.setVisible(true);
					txtRegistro.setVisible(true);
					
					btnCancelar.setVisible(false);
					btnConfirmar.setVisible(false);
					
					txtCompa.setEnabled(false);
					txtRfc.setEnabled(false);
					txtTel.setEnabled(false);
					txtDire.setEnabled(false);
					
					txtId.setText("");
					txtCompa.setText("");
					txtRfc.setText("");
					txtTel.setText("");
					txtDire.setText("");
					
					ShowPosInfo(0);
					
				}
				if(modoModificar==true) {
					compa�ia=txtCompa.getText();
					rfc=txtRfc.getText();
					direccion=txtDire.getText();
					telefono=txtTel.getText();
					id=txtId.getText();
				
					Connection con = conexion();
					String sqlupdate = "UPDATE proveedor SET Id_Proveedor = '"+ id + "',  Compa�ia  = '"+ compa�ia +"', RFC = '"+ rfc +"', Direccion = '"+ direccion +"', Telefono = '"+ telefono + "' WHERE Id_Proveedor = " + id ;
			 		if(compa�ia.isEmpty() || telefono.isEmpty() || rfc.isEmpty()|| direccion.isEmpty()) {
			 			sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
			 	        sonido.play();
			 			JOptionPane.showMessageDialog(null, "Error al momento de modificar","",JOptionPane.ERROR_MESSAGE,ico);
			 		}else {
			 			try {
			 	Statement stmt = con.createStatement();
	 	           stmt.executeUpdate(sqlupdate);
	 	          JOptionPane.showMessageDialog(btnAgregar, "Se han confirmado los cambios" , "Modificar",JOptionPane.INFORMATION_MESSAGE);
	 	        } catch (Exception e1) {
	 	        	sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
		 	        sonido.play();
		 			JOptionPane.showMessageDialog(null, "Error al momento de modificar","",JOptionPane.ERROR_MESSAGE,ico);
	 	        }
			 		}
					
					modoModificar=false;
					
					lblModo.setText("Modo: Lectura");
					
					lblId.setVisible(true);
					txtId.setVisible(true);
					btnAgregar.setVisible(true);
					btnModificar.setVisible(true);
					btnEliminar.setVisible(true);
					btnSalir.setVisible(true);
					btnI.setVisible(true);
					btnA.setVisible(true);
					btnS.setVisible(true);
					btnU.setVisible(true);
					txtRegistro.setVisible(true);
					
					btnCancelar.setVisible(false);
					btnConfirmar.setVisible(false);
					
					txtCompa.setEnabled(false);
					txtRfc.setEnabled(false);
					txtTel.setEnabled(false);
					txtDire.setEnabled(false);
						
					ShowPosInfo(pos);
					
				}
				if(modoEliminar==true) {
					
					id=txtId.getText();
					
					String SqlSt = "DELETE FROM proveedor WHERE Id_Proveedor= "+ id;
		 			Connection con = conexion();
		 	        try {
		 	        	Statement stmt = con.createStatement();
		 	            stmt.executeUpdate(SqlSt);
		 	           JOptionPane.showMessageDialog(btnEliminar, "Eliminacion Exitosa","Eliminar",JOptionPane.INFORMATION_MESSAGE);
		 	        } catch (Exception e1) {
		 	        	sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
		 	           sonido.play();
		 	   		JOptionPane.showMessageDialog(null, "No se pudo eliminar","",JOptionPane.ERROR_MESSAGE,ico);
		 	        }
					
					modoEliminar=false;
					
					lblModo.setText("Modo: Lectura");
					
					lblId.setVisible(true);
					txtId.setVisible(true);
					btnAgregar.setVisible(true);
					btnModificar.setVisible(true);
					btnEliminar.setVisible(true);
					btnSalir.setVisible(true);
					btnI.setVisible(true);
					btnA.setVisible(true);
					btnS.setVisible(true);
					btnU.setVisible(true);
					txtRegistro.setVisible(true);
					
					btnCancelar.setVisible(false);
					btnConfirmar.setVisible(false);
					
					txtCompa.setEnabled(false);
					txtRfc.setEnabled(false);
					txtTel.setEnabled(false);
					txtDire.setEnabled(false);
					
					txtId.setText("");
					txtCompa.setText("");
					txtRfc.setText("");
					txtTel.setText("");
					txtDire.setText("");
					
					ShowPosInfo(0);
					
				}
				
				}
			}
		});
		btnConfirmar.setBounds(295, 195, 135, 31);
		btnConfirmar.setVisible(false);
		contentPane.add(btnConfirmar);
		
		btnCancelar = new JButton(" Cancelar");
		btnCancelar.setIcon(new ImageIcon(JFrameProveedor.class.getResource("/Imagenes/no.png")));
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				modoAgregar=false;
				modoEliminar=false;
				modoModificar=false;
				
				lblModo.setText("Modo: Lectura");
				
				lblId.setVisible(true);
				txtId.setVisible(true);
				btnAgregar.setVisible(true);
				btnModificar.setVisible(true);
				btnEliminar.setVisible(true);
				btnSalir.setVisible(true);
				btnI.setVisible(true);
				btnA.setVisible(true);
				btnS.setVisible(true);
				btnU.setVisible(true);
				txtRegistro.setVisible(true);
				
				btnCancelar.setVisible(false);
				btnConfirmar.setVisible(false);
				
				txtCompa.setEnabled(false);
				txtRfc.setEnabled(false);
				txtTel.setEnabled(false);
				txtDire.setEnabled(false);
				
				txtId.setText("");
				txtCompa.setText("");
				txtRfc.setText("");
				txtTel.setText("");
				txtDire.setText("");
				
				ShowPosInfo(0);
							
			}
		});
		btnCancelar.setBounds(494, 195, 135, 31);
		btnCancelar.setVisible(false);
		contentPane.add(btnCancelar);
		
		txtRegistro = new JTextField();
		txtRegistro.setFont(new Font("Tahoma", Font.BOLD, 13));
		txtRegistro.setEnabled(false);
		txtRegistro.setBounds(308, 268, 118, 28);
		contentPane.add(txtRegistro);
		txtRegistro.setColumns(10);
		
		lblModo = new JLabel("Modo: Lectura");
		lblModo.setBounds(406, 11, 130, 14);
		contentPane.add(lblModo);
		
		ShowPosInfo(0);
	}
	static Connection conexion() {
		 Connection con1;
		 try {
			    Class.forName("com.mysql.jdbc.Driver");
			    con1 = DriverManager.getConnection("jdbc:mysql://localhost/nota","root", "");			   
			    return con1;
			} catch (Exception e) {
				 JOptionPane.showMessageDialog(null, "Error en la conexion con la Base de datos", "Error en B.D" ,JOptionPane.ERROR_MESSAGE);
				 }return null;
	}
	
	
	
	public static List<Proveedor> BindList(){
		 try{
	            Connection con = conexion();
	        	Statement stmt = con.createStatement();
	            ResultSet rs = stmt.executeQuery("SELECT * FROM  proveedor ");
	            List<Proveedor> list = new ArrayList<Proveedor>();
	            while(rs.next()){
	            	
	            	Proveedor u = new Proveedor(Integer.parseInt(rs.getString("Id_Proveedor")), 
	            			rs.getString("Compa�ia"), 
	            			rs.getString("RFC"), 
	            			rs.getString("Direccion"), 
	            			rs.getString("Telefono"));
	                list.add(u);
	            }
	            rs.close();
	            return list;
	        }catch(Exception ex){
	        	JOptionPane.showMessageDialog(null, "Listado no procesado" , "Insertar",JOptionPane.ERROR_MESSAGE);
	        }
	        return null;
   	
   }
		
	 public void ShowPosInfo(int index){
		 try {
					
	        txtId.setText(Integer.toString(BindList().get(index).getId()));
	        txtCompa.setText(BindList().get(index).getCompa�ia());
	        txtRfc.setText(BindList().get(index).getRFC());
	        txtDire.setText(BindList().get(index).getDireccion());
	        txtTel.setText(BindList().get(index).getTelefono());
	       
	        
	        txtRegistro.setText("Registro # " +Integer.toString(pos+1));
		 }catch(Exception g) {
			 JOptionPane.showMessageDialog(null, "No registros en la bd", "Error en B.D" ,JOptionPane.ERROR_MESSAGE);
		 }
		 	
	        
	    }
	
	
	
		
}
