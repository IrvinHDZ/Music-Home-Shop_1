package Proyecto;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.font.TextAttribute;
import java.awt.event.ActionEvent;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.JLabel;
import javax.swing.JSpinner;
import java.applet.AudioClip;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JRadioButton;
import javax.swing.SpinnerNumberModel;
import javax.swing.ButtonGroup;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.Color;
import java.awt.Cursor;

import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JInternalFrame;
import javax.swing.JRadioButtonMenuItem;
import java.awt.Canvas;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JMenuBar;



public class Tienda_Musica  extends JFrame{

int resultado=0;
public	AudioClip sonido;
static String nombre="", correo="", usuario="",contra="";
private JFrame frmLaBaseDe;
private JLabel lblModo, lblBienvenidoANuestra;
private JButton btnCrearNuevoUsuario, btnIniciarSesion, btnSalir, btnConfirmar,btnCancelar;
private JButton btnCerrarSesion;
private JButton btnInventario;
private JButton btnVendedor;
private JButton btnProveedor;
private JButton btnProductos;
private JButton btnDescuento;
private JButton btnVentas;
private JButton btnDesgloceDeVentas;
private JTextField txt,txtuser;
private JPasswordField passwordField;
private JCheckBox chckbxCambiar;

	public static void main(String[] args) {
		
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Tienda_Musica window = new  Tienda_Musica();
					window.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public  Tienda_Musica() {
		Connection con = conexion();
		Icon ico = new ImageIcon(getClass().getResource("/Proyecto/icono.gif"));
		sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/sm64_mario_press_start.wav"));
	    sonido.play();
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setTitle("La base de datos del proyecto");
		setBounds(100, 100, 562, 340);
		setResizable(false);
		getContentPane().setLayout(null);
		
		 btnIniciarSesion = new JButton("Iniciar Sesion");
		btnIniciarSesion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmLaBaseDe = new JFrame();
				frmLaBaseDe.setVisible(true);
				frmLaBaseDe.setIconImage(Toolkit.getDefaultToolkit().getImage(JFrameProductos.class.getResource("/Imagenes/gdm_login_photo.png")));
				frmLaBaseDe.setTitle("Iniciar Sesion");
				frmLaBaseDe.setResizable(false);
				frmLaBaseDe.setBounds(100, 100, 480, 256);
				frmLaBaseDe.getContentPane().setLayout(null);
				
				JButton btnConfirmar = new JButton("Confirmar");
				btnConfirmar.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						
						if(txtuser.getText().isEmpty() || passwordField.getText().isEmpty()) {
				 			sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
				 	        sonido.play();
				 			JOptionPane.showMessageDialog(null, "Campos Vacios >:(","",JOptionPane.ERROR_MESSAGE,ico);
						}else {
							if(chckbxCambiar.isSelected()) {
								try {
									Statement stmt = con.createStatement();
									ResultSet rs = stmt.executeQuery("SELECT * FROM usuario WHERE Correo= '"+txtuser.getText()+"' AND Contrase�a= '"+passwordField.getText()+"'");
									if(rs.next()) {
										resultado=1;
										frmLaBaseDe.dispose();
									}else {
										JOptionPane.showMessageDialog(null, "DATOS INCORRECTOS :(","ERROR!!!",JOptionPane.ERROR_MESSAGE);
									}
								}catch(Exception error) {
								}
							}else {
								try {
									Statement stmt = con.createStatement();
									ResultSet rs = stmt.executeQuery("SELECT * FROM usuario WHERE Nombre_Usuario= '"+txtuser.getText()+"' AND Contrase�a= '"+passwordField.getText()+"'");
									if(rs.next()) {
										resultado=1;
										frmLaBaseDe.dispose();
									}else {
										JOptionPane.showMessageDialog(null, "DATOS INCORRECTOS :(","ERROR!!!",JOptionPane.ERROR_MESSAGE);
									}
								}catch(Exception error) {
									
								}
							}
						}
					}
				});
				btnConfirmar.setIcon(new ImageIcon(Formulario.class.getResource("/Imagenes/tick_circle.png")));
				btnConfirmar.setBounds(44, 164, 135, 31);
				frmLaBaseDe.getContentPane().add(btnConfirmar);
				
				JButton btnCancelar = new JButton("Cancelar");
				btnCancelar.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						frmLaBaseDe.dispose();
					}
				});
				btnCancelar.setIcon(new ImageIcon(Formulario.class.getResource("/Imagenes/stock_exit.png")));
				btnCancelar.setBounds(239, 164, 135, 31);
				frmLaBaseDe.getContentPane().add(btnCancelar);
				
				JLabel lbl = new JLabel("Nombre de usuario:");
				lbl.setBounds(39, 26, 113, 14);
				frmLaBaseDe.getContentPane().add(lbl);
				
				JLabel lblContrasea = new JLabel("Contrase\u00F1a:");
				lblContrasea.setBounds(39, 82, 113, 14);
				frmLaBaseDe.getContentPane().add(lblContrasea);
				
				txtuser = new JTextField();
				txtuser.setBounds(162, 22, 165, 22);
				frmLaBaseDe.getContentPane().add(txtuser);
				txtuser.setColumns(10);
				
				passwordField = new JPasswordField();
				passwordField.setBounds(162, 78, 165, 22);
				frmLaBaseDe.getContentPane().add(passwordField);
				
				JLabel lblCambio = new JLabel("Olvide la contrase\u00F1a");
				Font font = lblCambio.getFont();
				Map attributes = font.getAttributes();
				attributes.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON);
				lblCambio.setFont(font.deriveFont(attributes));
				lblCambio.setForeground(Color.BLUE);
				lblCambio.setCursor(new Cursor(HAND_CURSOR));
				lblCambio.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						nombre = JOptionPane.showInputDialog(null,"Ingrese su nombre real","Confirmacion",JOptionPane.QUESTION_MESSAGE).toUpperCase();
						correo = JOptionPane.showInputDialog(null,"Ingrese su correo electronico","Confirmacion",JOptionPane.QUESTION_MESSAGE);
						usuario = JOptionPane.showInputDialog(null,"Ingrese su nombre de usuario","Confirmacion",JOptionPane.QUESTION_MESSAGE);
						contra = JOptionPane.showInputDialog(null,"Ingrese su NUEVA CONTRASE�A","Confirmacion",JOptionPane.QUESTION_MESSAGE);
						cambio();
						cambiar(0);
					}
				});
				lblCambio.setBounds(168, 128, 117, 14);
				frmLaBaseDe.getContentPane().add(lblCambio);
				
				chckbxCambiar = new JCheckBox("Cambiar a E-Mail");
				chckbxCambiar.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if(chckbxCambiar.isSelected()==true){
					lbl.setText("Correo electronico:");
					}else {
						lbl.setText("Nombre de usuario:");
					}
					}
				});
				chckbxCambiar.setBounds(333, 23, 135, 14);
				
				frmLaBaseDe.getContentPane().add(chckbxCambiar);
				
				
				/*
				sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/sm64_mario_here_we_go.wav"));
	 	        sonido.play();
	 	        String nivel=txt.getText();
	 	        JOptionPane.showMessageDialog(null,"Bienvenido de nuevo: ","Hola",JOptionPane.INFORMATION_MESSAGE);
	 	      
	 	    	  nombre=txtUsuario.getText();
	 	    	  contra=pass.getText();
	 	    	  nivel();
	 	    	 ShowPosInfo(0);
	 	      
	 	       if(nivel=="1") {
	 	    	  lblNombreDeUsuario.setVisible(false);
		 	      lblContrasea.setVisible(false);
		 	      txtUsuario.setVisible(false);
		 	      pass.setVisible(false);
		 	      lblBienvenidoANuestra.setVisible(false);
		 	      btnCrearNuevoUsuario.setVisible(false);
		 	      btnIniciarSesion.setVisible(false);
		 	      btnSalir.setVisible(false);
		 	      lblModo.setText("Modo: Iniciar sesion");
		 	      btnCerrarSesion.setVisible(true);
		 	      btnInventario.setVisible(true);
		 	      btnVendedor.setVisible(true);
		 	      btnProveedor.setVisible(true);
		 	      btnProductos.setVisible(true);
		 	      btnDescuento.setVisible(true);
		 	      btnVentas.setVisible(true);
		 	      btnDesgloceDeVentas.setVisible(true);
	 	      }
	 	       if(nivel=="2") {
	 	    	 
	 	      }
	 	       if(nivel=="3") {
	 	    	  
	 	       }
	 	       
	 	      
	 	  */
			}
		});
		btnIniciarSesion.setBounds(23, 243, 128, 23);
		getContentPane().add(btnIniciarSesion);
		
		lblBienvenidoANuestra = new JLabel("Bienvenido a la tienda \"La Nota\".");
		lblBienvenidoANuestra.setFont(new Font("Arial Black", Font.PLAIN, 18));
		lblBienvenidoANuestra.setBounds(59, 193, 331, 23);
		getContentPane().add(lblBienvenidoANuestra);
		
		 btnSalir = new JButton("Salir");
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				/*String name = JOptionPane.showInputDialog("Type your name please");
				JOptionPane.showMessageDialog(null, "Hello " + name);
				*/ 
				sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/sm64_mario_thank_you.wav"));
	 	        sonido.play();
				JOptionPane.showMessageDialog(null,"Nos vemos :)","Adios",JOptionPane.INFORMATION_MESSAGE);
				dispose();
			}
		});
		btnSalir.setBounds(408, 243, 89, 23);
		getContentPane().add(btnSalir);
		
		btnCrearNuevoUsuario = new JButton("Crear nuevo usuario");
		btnCrearNuevoUsuario.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				CrearUsuario newusuario=new CrearUsuario();
				newusuario.setVisible(true);
				
				sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/sm64_mario_hello.wav"));
	 	        sonido.play();	
			}
		});
		btnCrearNuevoUsuario.setBounds(189, 243, 196, 23);
		getContentPane().add(btnCrearNuevoUsuario);
			
			JMenuBar menuBar = new JMenuBar();
			menuBar.setBounds(0, 0, 99, 22);
			getContentPane().add(menuBar);
			
			JMenu menu=new JMenu("prueba");
			menu.setMnemonic(KeyEvent.VK_F);
			menuBar.add(menu);
			
			JRadioButtonMenuItem rdbtnmntmA = new JRadioButtonMenuItem("A");
			rdbtnmntmA.setMnemonic(KeyEvent.VK_A);
			menu.add(rdbtnmntmA);
			
			JRadioButtonMenuItem rdbtnmntmB = new JRadioButtonMenuItem("B");
			menu.add(rdbtnmntmB);
			
			lblModo = new JLabel("Modo: Lectura");
			lblModo.setBounds(408, 18, 128, 14);
			getContentPane().add(lblModo);
			
			 btnConfirmar = new JButton("Confirmar");
			 btnConfirmar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					
					
					
				}
			});
			 btnConfirmar.setBounds(289, 243, 96, 23);
			getContentPane().add(btnConfirmar);
			btnConfirmar.setVisible(false);
			
			
			btnCancelar = new JButton("Cancelar");
			btnCancelar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				}
			});
			btnCancelar.setBounds(408, 243, 89, 23);
			getContentPane().add(btnCancelar);
			btnCancelar.setVisible(false);
			
			btnCerrarSesion = new JButton("Cerrar Sesion");
			btnCerrarSesion.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					  lblBienvenidoANuestra.setVisible(true);
			 	      btnCrearNuevoUsuario.setVisible(true);
			 	      btnIniciarSesion.setVisible(true);
			 	      btnSalir.setVisible(true);
			 	     btnInventario.setVisible(false);
			 	    btnVendedor.setVisible(false);
			 	    btnProveedor.setVisible(false);
			 	    btnDescuento.setVisible(false);
			 	    btnProductos.setVisible(false);
			 	    btnVentas.setVisible(false);
			 	    btnDesgloceDeVentas.setVisible(false);
			 	      lblModo.setText("Modo: Lectura");
			 	      btnCerrarSesion.setVisible(false);
					
				}
			});
			btnCerrarSesion.setBounds(344, 268, 116, 23);
			getContentPane().add(btnCerrarSesion);
			btnCerrarSesion.setVisible(false);
			
			btnInventario = new JButton("Inventario");
			btnInventario.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JFrameInventario inventario=new JFrameInventario();
					inventario.setVisible(true);
								}
			});
			btnInventario.setBounds(272, 14, 106, 23);
			getContentPane().add(btnInventario);
			btnInventario.setVisible(false);
			
			btnVendedor = new JButton("Vendedor");
			btnVendedor.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JFrameVendedor jrvendedor=new JFrameVendedor();
					jrvendedor.setVisible(true);
				
				}
			});
			btnVendedor.setBounds(272, 44, 106, 23);
			getContentPane().add(btnVendedor);
			btnVendedor.setVisible(false);
			
			btnProveedor = new JButton("Proveedor");
			btnProveedor.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					JFrameProveedor jfproveedor=new JFrameProveedor();
					jfproveedor.setVisible(true);	
				}
			});
			btnProveedor.setBounds(272, 75, 106, 23);
			getContentPane().add(btnProveedor);
			btnProveedor.setVisible(false);
			
			btnProductos = new JButton("Productos");
			btnProductos.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JFrameProductos jfproductos=new JFrameProductos();
					jfproductos.setVisible(true);
				}
			});
			btnProductos.setBounds(272, 109, 106, 23);
			getContentPane().add(btnProductos);
			btnProductos.setVisible(false);
			
			btnDescuento = new JButton("Descuento");
			btnDescuento.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				JFrameDescuento descuento=new JFrameDescuento();
				descuento.setVisible(true);
				}
			});
			btnDescuento.setBounds(272, 143, 106, 23);
			getContentPane().add(btnDescuento);
			btnDescuento.setVisible(false);
			
			btnVentas = new JButton("Ventas");
			btnVentas.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JFrameVenta ventas=new JFrameVenta();
					ventas.setVisible(true);
				}
			});
			btnVentas.setBounds(272, 177, 106, 23);
			getContentPane().add(btnVentas);
			btnVentas.setVisible(false);
			
			btnDesgloceDeVentas = new JButton("Desglose de ventas");
			btnDesgloceDeVentas.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JFrameDesglose_Ventas des=new JFrameDesglose_Ventas();
					
					des.setVisible(true);
				}
			});
			btnDesgloceDeVentas.setBounds(250, 212, 155, 23);
			getContentPane().add(btnDesgloceDeVentas);
			
			txt = new JTextField();
			txt.setText("prueba");
			txt.setBounds(3, 277, 25, 20);
			getContentPane().add(txt);
			txt.setColumns(10);
			//txt.setVisible(false);
			
			
			
			btnCerrarSesion.setVisible(false);
			btnDesgloceDeVentas.setVisible(false);
	}
	
	public static Connection conexion() {
		Connection con1;
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			con1 = DriverManager.getConnection("jdbc:mysql://localhost/nota", "root", "");
			return con1;
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Error en la conexion con la Base de datos", "Error en B.D",JOptionPane.ERROR_MESSAGE);
		}
		return null;

	}
	
	public static List<Usuario> cambio(){
		 try{
	            Connection con = conexion();
	        	Statement stmt = con.createStatement();
	            ResultSet rs = stmt.executeQuery("SELECT * FROM `usuario` WHERE Nombre='"+nombre+"' AND Nombre_Usuario='"+usuario+"' AND Correo='"+correo+"'");
	            List<Usuario> list = new ArrayList<Usuario>();
	            while(rs.next()){
	            	Usuario u = new Usuario(rs.getString("Id_Usuario"), 
	            			rs.getString("Nombre"), 
	            			rs.getString("Apellido_Paterno"), 
	            			rs.getString("Apellido_Materno"),
	            			rs.getString("Nombre_Usuario"), 
	            			rs.getString("Contrase�a"), 
	            			rs.getString("Correo"), 
	            			rs.getString("Nivel"));
	                list.add(u);
	            }
	            
	            return list;
	        }catch(Exception ex){
	        }
	        return null;
 	
 }
	
	 public void cambiar(int index){
		 try {
			 Connection con = conexion();
			String sqlupdate = "UPDATE usuario SET Id_Usuario="+ cambio().get(index).getId_Usuario() +",Nombre='"+cambio().get(index).getNombre()+"',Apellido_Paterno='"+cambio().get(index).getApellido_P()+"',Apellido_Materno='"+cambio().get(index).getApellido_M()+"',Nombre_Usuario='"+cambio().get(index).getUsuario()+"',Contrase�a='"+contra+"',Correo='"+cambio().get(index).getCorreo()+"',Nivel='"+cambio().get(index).getNivel()+"' WHERE Id_Usuario = " +cambio().get(index).getId_Usuario(); 
			/* txt.setText(cambio().get(index).getNivel()); 
		   	String sqlupdate = "UPDATE productos SET `Id_Producto`='"+ id + "',  `Nombre`  = '"+ nombre +"', `Descripci�n` = '"+ descripcion +"', `Precio` = '"+ precio +"',  `Cantidad`  = '"+ cantidad +"', `Ruta_Imagen` = '"+ ruta +"', `Activado` = '"+ activado +"', `Categor�a` = '"+ categoria +"', `Marca` = '"+ marca +"', `Id_Proveedor` = '"+ aux +"' WHERE Id_Producto = " + id ;
			 * 
			 * */
		 	Statement stmt = con.createStatement();
 	           stmt.executeUpdate(sqlupdate);
 	          JOptionPane.showMessageDialog(null, "La Contrase�a ha sido cambiada exitosamente" , "Modificar",JOptionPane.INFORMATION_MESSAGE);
		 }catch(Exception e) {
			 JOptionPane.showMessageDialog(null, "Error en los datos", "ERROR!!!" ,JOptionPane.ERROR_MESSAGE);
		 }
	        
	        
	    }
	
	
}