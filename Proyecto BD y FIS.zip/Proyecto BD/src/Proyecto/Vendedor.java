package Proyecto;
public class Vendedor {
private int Id;
private String Nombre, A_paterno,A_materno;
public Vendedor(int id, String nombre, String a_paterno, String a_materno) {
	Id = id;
	Nombre = nombre;
	A_paterno = a_paterno;
	A_materno = a_materno;
}
public Vendedor(int id) {
	Id = id;
}
public int getId() {
	return Id;
}
public void setId(int id) {
	Id = id;
}
public String getNombre() {
	return Nombre;
}
public void setNombre(String nombre) {
	Nombre = nombre;
}
public String getA_paterno() {
	return A_paterno;
}
public void setA_paterno(String a_paterno) {
	A_paterno = a_paterno;
}
public String getA_materno() {
	return A_materno;
}
public void setA_materno(String a_materno) {
	A_materno = a_materno;
}



}
