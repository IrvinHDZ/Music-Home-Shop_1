package Proyecto;

public class Desgloce {
	private int Id_Producto;
	private int Id_Ventas,Cantidad,Total;
	public Desgloce(int id_Producto, int id_Ventas, int cantidad, int total) {
		Id_Producto = id_Producto;
		Id_Ventas = id_Ventas;
		Cantidad = cantidad;
		Total = total;
	}
	public int getId_Producto() {
		return Id_Producto;
	}
	public void setId_Producto(int id_Producto) {
		Id_Producto = id_Producto;
	}
	public int getId_Ventas() {
		return Id_Ventas;
	}
	public void setId_Ventas(int id_Ventas) {
		Id_Ventas = id_Ventas;
	}
	public int getCantidad() {
		return Cantidad;
	}
	public void setCantidad(int cantidad) {
		Cantidad = cantidad;
	}
	public int getTotal() {
		return Total;
	}
	public void setTotal(int total) {
		Total = total;
	}

}
