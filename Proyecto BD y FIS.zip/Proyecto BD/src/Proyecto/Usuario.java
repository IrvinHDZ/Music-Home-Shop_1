package Proyecto;

public class Usuario {

private String Nivel, Id_Usuario,Nombre,Apellido_P,Apellido_M,Contrase�a,Correo,Usuario;

public Usuario(String id_Usuario, String nombre, String apellido_P, String apellido_M, String usuario, String contrase�a,String correo,String nivel) {
	Nivel = nivel;
	Id_Usuario = id_Usuario;
	Nombre = nombre;
	Apellido_P = apellido_P;
	Apellido_M = apellido_M;
	Contrase�a = contrase�a;
	Correo = correo;
	Usuario = usuario;
}
public Usuario() {
	
}


public String getNivel() {
	return Nivel;
}

public void setNivel(String nivel) {
	Nivel = nivel;
}

public String getId_Usuario() {
	return Id_Usuario;
}

public void setId_Usuario(String id_Usuario) {
	Id_Usuario = id_Usuario;
}

public String getNombre() {
	return Nombre;
}

public void setNombre(String nombre) {
	Nombre = nombre;
}

public String getApellido_P() {
	return Apellido_P;
}

public void setApellido_P(String apellido_P) {
	Apellido_P = apellido_P;
}

public String getApellido_M() {
	return Apellido_M;
}

public void setApellido_M(String apellido_M) {
	Apellido_M = apellido_M;
}

public String getContrase�a() {
	return Contrase�a;
}

public void setContrase�a(String contrase�a) {
	Contrase�a = contrase�a;
}

public String getCorreo() {
	return Correo;
}

public void setCorreo(String correo) {
	Correo = correo;
}

public String getUsuario() {
	return Usuario;
}

public void setUsuario(String usuario) {
	Usuario = usuario;
}


}
