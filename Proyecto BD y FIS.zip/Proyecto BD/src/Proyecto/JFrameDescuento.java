package Proyecto;

import java.applet.AudioClip;
import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.awt.event.ActionEvent;
import com.toedter.calendar.JDateChooser;

public class JFrameDescuento extends JFrame {
	int pos=0;
	public	AudioClip sonido;
	ResultSet rs;
	PreparedStatement ps;
	boolean modoAgregar=false,modoEliminar=false,modoModificar=false;
	private JPanel contentPane;
	private JTextField txtId;
	private JTextField txtFecha;
	private JTextField txtPor;
	private JButton btnI;
	private JButton btnA;
	private JButton btnS;
	private JButton btnU;
	private JButton btnAgregar;
	private JButton btnModificar;
	private JButton btnEliminar;
	private JButton btnConfirmar;
	private JButton btnCancelar;
	private JTextField txtRegistro;
	private JLabel lblModo;
	private JComboBox comboBoxProducto;
	private JDateChooser dateChooser;
	private JSpinner spinner;
	private JTextField txtIdPro;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JFrameDescuento frame = new JFrameDescuento();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public JFrameDescuento() {
		Connection con = conexion();
		Icon ico = new ImageIcon(getClass().getResource("/Proyecto/icono.gif"));
		
		setTitle("Base de Datos del Descuento");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 562, 340);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtFecha = new JTextField();
		txtFecha.setEnabled(false);
		txtFecha.setBounds(142, 167, 190, 20);
		contentPane.add(txtFecha);
		txtFecha.setColumns(10);
		
		JLabel lblId = new JLabel("Id Descuento: ");
		lblId.setBounds(10, 11, 122, 14);
		contentPane.add(lblId);
		
		txtId = new JTextField();
		txtId.setEnabled(false);
		txtId.setBounds(142, 8, 190, 20);
		contentPane.add(txtId);
		txtId.setColumns(10);
		
		JLabel lblCompa = new JLabel("Id Producto:");
		lblCompa.setBounds(10, 76, 122, 14);
		contentPane.add(lblCompa);
		
		JLabel lblDire = new JLabel("Fecha:");
		lblDire.setBounds(10, 173, 122, 14);
		contentPane.add(lblDire);
		
		JLabel lblRfc = new JLabel("Porcentaje:");
		lblRfc.setBounds(10, 121, 122, 14);
		contentPane.add(lblRfc);
		
		txtPor = new JTextField();
		txtPor.setEnabled(false);
		txtPor.setBounds(142, 118, 190, 20);
		contentPane.add(txtPor);
		txtPor.setColumns(10);
		
		JButton btnSalir = new JButton("Salir");
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnSalir.setBounds(406, 234, 89, 23);
		contentPane.add(btnSalir);
		
		btnI = new JButton("Inicio");
		btnI.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pos = 0;
	            ShowPosInfo(pos);
			}
		});
		btnI.setBounds(0, 268, 89, 23);
		contentPane.add(btnI);
		
		btnA = new JButton("Anterior");
		btnA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pos--;
	            if(pos >= 0){
	                ShowPosInfo(pos);                
	            }
	            else{
	            	if(pos < 0){
	            		sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
	                    sonido.play(); 
	            		JOptionPane.showMessageDialog(null, "Ya es el primer registro","",JOptionPane.ERROR_MESSAGE,ico);
		                    pos = 0;            
		            }
	                
	            }
				
			}
		});
		btnA.setBounds(99, 268, 89, 23);
		contentPane.add(btnA);
		
		btnS = new JButton("Siguiente");
		btnS.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pos++;
	               if(pos < BindList().size()){
	                   ShowPosInfo(pos);
	               }
	               else{
	                   pos = BindList().size() - 1;
	                   ShowPosInfo(pos);
	                   sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
	                   sonido.play();
	           		JOptionPane.showMessageDialog(null, "Ya es el ultimo registro","",JOptionPane.ERROR_MESSAGE,ico);
	               }
			}
		});
		btnS.setBounds(361, 268, 89, 23);
		contentPane.add(btnS);
		
		btnU = new JButton("Ultimo");
		btnU.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pos = BindList().size() - 1;
				ShowPosInfo(pos);
			}
		});
		btnU.setBounds(457, 268, 89, 23);
		contentPane.add(btnU);
		
		btnAgregar = new JButton("Agregar");
		btnAgregar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				spinner.setValue(0);
				
				modoAgregar=true;
				
				dateChooser.setDate(null);
				
				lblModo.setText("Modo: Agregar");
				
				lblId.setVisible(false);
				txtId.setVisible(false);
				btnAgregar.setVisible(false);
				btnModificar.setVisible(false);
				btnEliminar.setVisible(false);
				btnSalir.setVisible(false);
				btnI.setVisible(false);
				btnA.setVisible(false);
				txtIdPro.setVisible(false);
				btnS.setVisible(false);
				btnU.setVisible(false);
				txtRegistro.setVisible(false);
				txtPor.setVisible(false);
				txtFecha.setVisible(false);
				
				dateChooser.setVisible(true);
				dateChooser.setEnabled(true);
				spinner.setVisible(true);
				spinner.setEnabled(true);
				
				btnCancelar.setVisible(true);
				btnConfirmar.setVisible(true);
				
				comboBoxProducto.setEnabled(true);
				
				txtId.setText("");
				txtPor.setText("");
				txtFecha.setText("");
				
				
			}
		});
		btnAgregar.setBounds(43, 234, 89, 23);
		contentPane.add(btnAgregar);
		
		btnModificar = new JButton("Modificar");
		btnModificar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				comboBoxProducto.setSelectedItem(txtIdPro.getText());
				
				int valor=0;
				valor=Integer.parseInt(txtPor.getText());
				spinner.setValue(valor);
				try {
					int j=0;
					String an="",me="",di="";
					String ayuda=txtFecha.getText()+"-";
					while(ayuda.charAt(j)!='-') {
						an=an+ayuda.substring(j,j+1);
						j++;
					}
					while(ayuda.charAt(j+1)!='-') {
						me=me+ayuda.substring(j+1,j+2);
						j++;
					}		
					
					while(ayuda.charAt(j+2)!='-') {
						di=di+ayuda.substring((j+2),(j+3));
						j++;
					}
					String fechaact=an+"-"+me+"-"+di;
					SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
					try {
						Date date= formatter.parse(fechaact);
						dateChooser.setDate(date);
					} catch (Exception e2) {
						
						JOptionPane.showMessageDialog(btnAgregar, "Fecha NO cambiada", "Modificar",JOptionPane.INFORMATION_MESSAGE);
					}
					
				} catch (Exception e2) {
				}
				modoModificar=true;
				
				lblModo.setText("Modo: Modificar");
				
				lblId.setVisible(false);
				txtId.setVisible(false);
				btnAgregar.setVisible(false);
				btnModificar.setVisible(false);
				btnEliminar.setVisible(false);
				btnSalir.setVisible(false);
				btnI.setVisible(false);
				txtIdPro.setVisible(false);
				btnA.setVisible(false);
				btnS.setVisible(false);
				btnU.setVisible(false);
				txtRegistro.setVisible(false);
				
				btnCancelar.setVisible(true);
				btnConfirmar.setVisible(true);
				
				comboBoxProducto.setEnabled(true);
				txtPor.setVisible(false);
				txtFecha.setVisible(false);
				
				dateChooser.setVisible(true);
				dateChooser.setEnabled(true);
				spinner.setVisible(true);
				spinner.setEnabled(true);
				
			}
		});
		btnModificar.setBounds(158, 234, 89, 23);
		contentPane.add(btnModificar);
		
		btnEliminar = new JButton("Eliminar");
		btnEliminar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				modoEliminar=true;
				
				lblModo.setText("Modo: Eliminar");
				
				btnAgregar.setVisible(false);
				btnModificar.setVisible(false);
				btnEliminar.setVisible(false);
				btnSalir.setVisible(false);
				btnI.setVisible(false);
				btnA.setVisible(false);
				btnS.setVisible(false);
				btnU.setVisible(false);
				txtRegistro.setVisible(false);
				
				btnCancelar.setVisible(true);
				btnConfirmar.setVisible(true);
				
				
			}
		});
		btnEliminar.setBounds(284, 234, 89, 23);
		contentPane.add(btnEliminar);
		
		btnConfirmar = new JButton("Confirmar");
		btnConfirmar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int confirmado = JOptionPane.showConfirmDialog(null,"Presione YES para confirmar. \nPresione NO para anular accion.","Confirmacion",JOptionPane.YES_NO_OPTION);

				if (JOptionPane.YES_OPTION == confirmado) {
				String idPro, fecha, id;
				int porcentaje;
				if (modoAgregar == true) {
					
					//Adaptar la fecha al gestor
					String dia="00";String mes="00";String year="0000";
					try {
					dia= Integer.toString(dateChooser.getCalendar().get(Calendar.DAY_OF_MONTH));
					mes= Integer.toString(dateChooser.getCalendar().get(Calendar.MONTH) + 1);
					year=Integer.toString(dateChooser.getCalendar().get(Calendar.YEAR));
					}catch(Exception error) {
					}
					
					fecha=year+"-"+mes+"-"+dia;
					
					porcentaje = (Integer) spinner.getValue();
					
					idPro=(String) comboBoxProducto.getSelectedItem();
			 		int i=0;
					String aux="";
					if(idPro.contains(".")) {
			 			while(idPro.charAt(i)!='.') {
			 			aux=aux+idPro.substring(i,(i+1));
			 			i++;
			 		}
			 			}else {
			 				aux=idPro;
			 			}
			 		

					Connection con = conexion();
					
					if ( fecha=="000-00-00" ) {
						sonido = java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
						sonido.play();
						JOptionPane.showMessageDialog(null, "Error al momento de agregar", "",JOptionPane.ERROR_MESSAGE, ico);
					} else {
						String sqlInsert = "INSERT INTO descuento(`Id_Producto`, `Porcentaje`, `Fecha`) values ('"+ aux + "','"+ porcentaje + "','" + fecha + "')";
						try {
							Statement stmt = con.createStatement();
							stmt.executeUpdate(sqlInsert);
							JOptionPane.showMessageDialog(btnAgregar, "Se ha guardado el Registro", "Insertar",JOptionPane.INFORMATION_MESSAGE);

						} catch (Exception e1) {
							sonido = java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
							sonido.play();
							JOptionPane.showMessageDialog(null, "Error al agregar", "", JOptionPane.ERROR_MESSAGE, ico);
						}
					}
										
					modoAgregar = false;

					lblModo.setText("Modo: Lectura");
					
					lblId.setVisible(true);
					txtId.setVisible(true);
					btnAgregar.setVisible(true);
					btnModificar.setVisible(true);
					btnEliminar.setVisible(true);
					btnSalir.setVisible(true);
					btnI.setVisible(true);
					btnA.setVisible(true);
					btnS.setVisible(true);
					btnU.setVisible(true);
					txtRegistro.setVisible(true);
					
					btnCancelar.setVisible(false);
					btnConfirmar.setVisible(false);
					
					comboBoxProducto.setEnabled(false);
					txtPor.setEnabled(false);
					txtFecha.setEnabled(false);
					txtIdPro.setVisible(true);
					txtId.setText("");
					txtPor.setText("");
					txtFecha.setText("");
					
					
					txtPor.setVisible(true);
					txtFecha.setVisible(true);
					
					dateChooser.setVisible(false);
					dateChooser.setEnabled(false);
					spinner.setVisible(false);
					spinner.setEnabled(false);
					
					ShowPosInfo(0);

				}

				if (modoModificar == true) {					
					
					//Adaptar la fecha al gestor
					String dia="00";String mes="00";String year="0000";
					try {
					dia= Integer.toString(dateChooser.getCalendar().get(Calendar.DAY_OF_MONTH));
					mes= Integer.toString(dateChooser.getCalendar().get(Calendar.MONTH) + 1);
					year=Integer.toString(dateChooser.getCalendar().get(Calendar.YEAR));
					}catch(Exception error) {
					}
					
					fecha=year+"-"+mes+"-"+dia;
					
					porcentaje = (Integer) spinner.getValue();
					id=txtId.getText();
					
					idPro=(String) comboBoxProducto.getSelectedItem();
			 		int i=0;
					String aux="";
					if(idPro.contains(".")) {
			 			while(idPro.charAt(i)!='.') {
			 			aux=aux+idPro.substring(i,(i+1));
			 			i++;
			 		}
			 			}else {
			 				aux=idPro;
			 			}

					Connection con = conexion();
					
					String sqlupdate = "UPDATE descuento SET `Id_Descuento`='"+ id +"',`Id_Producto`='"+ aux +"',`Porcentaje`='"+ porcentaje +"',`Fecha`='"+ fecha +"' WHERE Id_Descuento = " + id;
					 
					 if( fecha=="000-00-00" ) {
					 JOptionPane.showMessageDialog(null, "Error al momento de modificar :(","ERROR!!!" ,JOptionPane.ERROR_MESSAGE);
					sonido = java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
					sonido.play();
					Icon ico = new ImageIcon(getClass().getResource("/Proyecto/icono.gif"));
					JOptionPane.showMessageDialog(null, "Error al momento de modificar", "", JOptionPane.ERROR_MESSAGE,
							ico);
					 }else {
					try {
						Statement stmt = con.createStatement();
						 stmt.executeUpdate(sqlupdate);
						JOptionPane.showMessageDialog(btnAgregar, "Se han confirmado los cambios", "Modificar",JOptionPane.INFORMATION_MESSAGE);
					} catch (Exception e1) {
						sonido = java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
						sonido.play();
						JOptionPane.showMessageDialog(null, "Error al momento de modificar", "",
								JOptionPane.ERROR_MESSAGE, ico);
					}
					 }

					modoModificar = false;
					lblModo.setText("Modo: Lectura");
					
					lblId.setVisible(true);
					txtId.setVisible(true);
					btnAgregar.setVisible(true);
					btnModificar.setVisible(true);
					btnEliminar.setVisible(true);
					btnSalir.setVisible(true);
					btnI.setVisible(true);
					btnA.setVisible(true);
					btnS.setVisible(true);
					btnU.setVisible(true);
					txtRegistro.setVisible(true);
					txtIdPro.setVisible(true);
					btnCancelar.setVisible(false);
					btnConfirmar.setVisible(false);
					
					comboBoxProducto.setEnabled(false);
					txtPor.setEnabled(false);
					txtFecha.setEnabled(false);
					
					txtId.setText("");
					txtPor.setText("");
					txtFecha.setText("");
					
					
					txtPor.setVisible(true);
					txtFecha.setVisible(true);
					
					dateChooser.setVisible(false);
					dateChooser.setEnabled(false);
					spinner.setVisible(false);
					spinner.setEnabled(false);
					
					ShowPosInfo(pos);
				}
				if (modoEliminar == true) {
					
					id=txtId.getText();
					
					 String SqlSt = "DELETE FROM descuento WHERE Id_Descuento= "+ id;
					Connection con = conexion();
					try {
						Statement stmt = con.createStatement();
						 stmt.executeUpdate(SqlSt);

						JOptionPane.showMessageDialog(btnEliminar, "Eliminacion Exitosa", "Eliminar",JOptionPane.INFORMATION_MESSAGE);
					} catch (Exception e1) {
						sonido = java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
						sonido.play();
						JOptionPane.showMessageDialog(null, "No se pudo eliminar", "", JOptionPane.ERROR_MESSAGE, ico);
					}
					modoEliminar = false;
					
lblModo.setText("Modo: Lectura");
					
					lblId.setVisible(true);
					txtId.setVisible(true);
					btnAgregar.setVisible(true);
					btnModificar.setVisible(true);
					btnEliminar.setVisible(true);
					btnSalir.setVisible(true);
					btnI.setVisible(true);
					btnA.setVisible(true);
					btnS.setVisible(true);
					btnU.setVisible(true);
					txtRegistro.setVisible(true);
					
					btnCancelar.setVisible(false);
					btnConfirmar.setVisible(false);
					
					comboBoxProducto.setEnabled(false);
					txtPor.setEnabled(false);
					txtFecha.setEnabled(false);
					
					txtId.setText("");
					txtPor.setText("");
					txtFecha.setText("");
					
					
					txtPor.setVisible(true);
					txtFecha.setVisible(true);
					
					dateChooser.setVisible(false);
					dateChooser.setEnabled(false);
					spinner.setVisible(false);
					spinner.setEnabled(false);
					
					ShowPosInfo(0);
				}
				}else {
					
				}
			}
		});
		btnConfirmar.setBounds(208, 234, 97, 23);
		btnConfirmar.setVisible(false);
		contentPane.add(btnConfirmar);
		
		btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				modoAgregar=false;
				modoEliminar=false;
				modoModificar=false;
				
				lblModo.setText("Modo: Lectura");
				
				lblId.setVisible(true);
				txtId.setVisible(true);
				btnAgregar.setVisible(true);
				btnModificar.setVisible(true);
				btnEliminar.setVisible(true);
				btnSalir.setVisible(true);
				btnI.setVisible(true);
				btnA.setVisible(true);
				btnS.setVisible(true);
				btnU.setVisible(true);
				txtRegistro.setVisible(true);
				txtIdPro.setVisible(true);
				btnCancelar.setVisible(false);
				btnConfirmar.setVisible(false);
				
				comboBoxProducto.setEnabled(false);
				txtPor.setEnabled(false);
				txtFecha.setEnabled(false);
				
				txtId.setText("");
				txtPor.setText("");
				txtFecha.setText("");
				
				
				txtPor.setVisible(true);
				txtFecha.setVisible(true);
				
				dateChooser.setVisible(false);
				dateChooser.setEnabled(false);
				spinner.setVisible(false);
				spinner.setEnabled(false);
				
				ShowPosInfo(0);
							
			}
		});
		btnCancelar.setBounds(347, 234, 89, 23);
		btnCancelar.setVisible(false);
		contentPane.add(btnCancelar);
		
		txtRegistro = new JTextField();
		txtRegistro.setEnabled(false);
		txtRegistro.setBounds(190, 269, 170, 20);
		contentPane.add(txtRegistro);
		txtRegistro.setColumns(10);
		
		lblModo = new JLabel("Modo: Lectura");
		lblModo.setBounds(406, 11, 130, 14);
		contentPane.add(lblModo);
		
		dateChooser = new JDateChooser();
		dateChooser.setBounds(142, 167, 190, 20);
		dateChooser.setDateFormatString("yyyy-MM-dd");
		dateChooser.setVisible(false);
		dateChooser.setEnabled(false);
		contentPane.add(dateChooser);
		
		spinner = new JSpinner();
		spinner.setEnabled(false);
		spinner.setVisible(false);
		spinner.setBounds(142, 118, 46, 20);
		spinner.setModel(new SpinnerNumberModel(0, 0, 100, 1));
		contentPane.add(spinner);
		
		txtIdPro = new JTextField();
		txtIdPro.setEnabled(false);
		txtIdPro.setColumns(10);
		txtIdPro.setBounds(142, 72, 190, 23);
		contentPane.add(txtIdPro);
		
		comboBoxProducto = new JComboBox();
		comboBoxProducto.setEnabled(false);
		comboBoxProducto.setBounds(142, 72, 190, 22);
		contentPane.add(comboBoxProducto);
		
		ShowPosInfo(0);
		mostrarProducto();
	}
	static Connection conexion() {
		 Connection con1;
		 try {
			    Class.forName("com.mysql.jdbc.Driver");
			    con1 = DriverManager.getConnection("jdbc:mysql://localhost/nota","root", "");			   
			    return con1;
			} catch (Exception e) {
				 JOptionPane.showMessageDialog(null, "Error en la conexion con la Base de datos", "Error en B.D" ,JOptionPane.ERROR_MESSAGE);
				 }return null;
	}
	
	void mostrarProducto(){
		Connection conec = conexion();
		String sql="SELECT * FROM productos";
		try{
		Statement st=conec.createStatement();
		ResultSet rs= st.executeQuery(sql);
		while(rs.next()){
		comboBoxProducto.addItem(rs.getString("Id_Producto") +".-" + rs.getString("Nombre"));
		comboBoxProducto.addItem(rs.getString("Id_Producto"));
		}
		
		}
		catch(Exception e){
			sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
 	        sonido.play();		
 			Icon ico=new ImageIcon(getClass().getResource("/Proyecto/icono.gif")); 
 			JOptionPane.showMessageDialog(null, "Llave foranea no conectada","",JOptionPane.ERROR_MESSAGE,ico);
		}
		}
	
	public static List<Descuento> BindList() {
		try {
			Connection con = conexion();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM  descuento ");
			List<Descuento> list = new ArrayList<Descuento>();
			while (rs.next()) {

				Descuento u = new Descuento(rs.getString("Id_Producto"), 
						rs.getString("Fecha"),
						Integer.parseInt(rs.getString("Id_Descuento")), 
						Integer.parseInt(rs.getString("Porcentaje")));

				list.add(u);
			}

			return list;
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(null, "Listado no procesado" , "Insertar",JOptionPane.ERROR_MESSAGE);
		}
		return null;

	}

	public void ShowPosInfo(int index) {
		try {

	        txtIdPro.setText(BindList().get(index).getId_Producto());
			txtPor.setText(Integer.toString(BindList().get(index).getPorcentaje()));
			txtId.setText(Integer.toString(BindList().get(index).getId()));
			txtFecha.setText(BindList().get(index).getFecha());
			
			txtRegistro.setText("Registro # " + Integer.toString(pos + 1));
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "No registros en la bd", "", JOptionPane.ERROR_MESSAGE);
		}

	}
}
