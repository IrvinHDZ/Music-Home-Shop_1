package Proyecto;

import java.applet.AudioClip;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.print.DocFlavor.STRING;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.font.TextAttribute;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.awt.Color;
import java.awt.Cursor;

public class CrearUsuario extends JFrame {
	
	int nivel=3;
	static String id="";
	private JPanel contentPane;
	private JTextField txtNom;
	private JTextField txtPaterno;
	private JTextField txtMaterno;
	private JTextField txtNomUser;
	private JPasswordField txtContra;
	private JPasswordField txtContra2;
	private JTextField txtCorreo;
	AudioClip sonido;
	private JLabel lbleresEmpleado;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CrearUsuario frame = new CrearUsuario();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public CrearUsuario() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(CrearUsuario.class.getResource("/Imagenes/ICONO_CREAR.png")));
		Icon ico = new ImageIcon(getClass().getResource("/Proyecto/icono.gif"));
		setTitle("Nuevo Usuario");
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 451, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setResizable(false);
		contentPane.setLayout(null);
		
		JLabel lblIngreseSuNombres = new JLabel("Ingrese su(s) Nombre(s):");
		lblIngreseSuNombres.setBounds(10, 11, 190, 14);
		contentPane.add(lblIngreseSuNombres);
		
		txtNom = new JTextField();
		txtNom.setBounds(210, 8, 169, 20);
		contentPane.add(txtNom);
		txtNom.setColumns(10);
		
		JLabel lblIngreseSuApellido = new JLabel("Ingrese su Apellido Paterno:");
		lblIngreseSuApellido.setBounds(10, 36, 169, 14);
		contentPane.add(lblIngreseSuApellido);
		
		txtPaterno = new JTextField();
		txtPaterno.setColumns(10);
		txtPaterno.setBounds(210, 33, 169, 20);
		contentPane.add(txtPaterno);
		
		JLabel lblIngreseSuApellido_1 = new JLabel("Ingrese su Apellido Materno:");
		lblIngreseSuApellido_1.setBounds(10, 61, 169, 14);
		contentPane.add(lblIngreseSuApellido_1);
		
		txtMaterno = new JTextField();
		txtMaterno.setColumns(10);
		txtMaterno.setBounds(210, 58, 169, 20);
		contentPane.add(txtMaterno);
		
		JLabel lblIngreseSuNombre = new JLabel("Ingrese su nombre de usuario:");
		lblIngreseSuNombre.setBounds(10, 86, 190, 14);
		contentPane.add(lblIngreseSuNombre);
		
		txtNomUser = new JTextField();
		txtNomUser.setColumns(10);
		txtNomUser.setBounds(210, 83, 169, 20);
		contentPane.add(txtNomUser);
		
		JLabel lblIngreseContrasea = new JLabel("Ingrese una Contrase\u00F1a:");
		lblIngreseContrasea.setBounds(10, 111, 190, 14);
		contentPane.add(lblIngreseContrasea);
		
		txtContra = new JPasswordField();
		txtContra.setBounds(210, 108, 169, 20);
		contentPane.add(txtContra);
		
		JLabel lblVuelvaAEscribir = new JLabel("Vuelva a escribir su Contrase\u00F1a:");
		lblVuelvaAEscribir.setBounds(10, 136, 200, 14);
		contentPane.add(lblVuelvaAEscribir);
		
		txtContra2 = new JPasswordField();
		txtContra2.setBounds(210, 133, 169, 20);
		contentPane.add(txtContra2);
		
		JLabel lblIngreseSuCorreo = new JLabel("Ingrese su Correo electronico:");
		lblIngreseSuCorreo.setBounds(10, 161, 200, 14);
		contentPane.add(lblIngreseSuCorreo);
		
		txtCorreo = new JTextField();
		txtCorreo.setBounds(210, 158, 169, 20);
		contentPane.add(txtCorreo);
		txtCorreo.setColumns(10);
		
		JButton btnConfirmar = new JButton(" Confirmar");
		btnConfirmar.setIcon(new ImageIcon(CrearUsuario.class.getResource("/Imagenes/tick_circle.png")));
		btnConfirmar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Connection con = conexion();
				
				int confirmado = JOptionPane.showConfirmDialog(null,"Presione YES para confirmar. \nPresione NO para anular accion.","Confirmacion",JOptionPane.YES_NO_OPTION);
				String Nom=txtNom.getText().toUpperCase(),Ap=txtPaterno.getText().toUpperCase(),Am=txtMaterno.getText().toUpperCase(),NomU=txtNomUser.getText(),Contra=txtContra.getText(),Contra2=txtContra2.getText(),Correo=txtCorreo.getText();
				char[] password=txtContra.getPassword();
				char[] password2=txtContra2.getPassword();
				int resultado=0,resultadoc=0;
				if (JOptionPane.YES_OPTION == confirmado) {
				try {
					String sql="SELECT * FROM usuario WHERE Nombre_Usuario= '"+NomU+"'";
					Statement stmt = con.createStatement();
					ResultSet rs = stmt.executeQuery(sql);
					if(rs.next()) {
						resultado=1;
					}
				}catch(Exception error) {
					JOptionPane.showMessageDialog(null, "HELP","",JOptionPane.ERROR_MESSAGE);
				}
				try {
					String sqlc="SELECT * FROM usuario WHERE Correo= '"+Correo+"'";
					Statement stmt = con.createStatement();
					ResultSet rs = stmt.executeQuery(sqlc);
					if(rs.next()) {
						resultadoc=1;
					}
				}catch(Exception error) {
					JOptionPane.showMessageDialog(null, "HELP","",JOptionPane.ERROR_MESSAGE);
				}
					
					if(Nom.isEmpty()||Ap.isEmpty()||NomU.isEmpty()||Contra.isEmpty()||Contra2.isEmpty()||Correo.isEmpty()) {
						sonido = java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
			 	        sonido.play();
						JOptionPane.showMessageDialog(null, "Error al crear usuario","",JOptionPane.ERROR_MESSAGE,ico);
					}else {
						if(!Arrays.equals(password,password2)) {
							sonido = java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
				 	        sonido.play();
							JOptionPane.showMessageDialog(null, "Las Contrase�as NO coinciden","",JOptionPane.ERROR_MESSAGE,ico);
						}
						else {
							if(!Correo.contains("@") || !Correo.contains(".com")) {
								sonido = java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
					 	        sonido.play();
								JOptionPane.showMessageDialog(null, "Correo electronico NO valido","",JOptionPane.ERROR_MESSAGE,ico);
							} else {
								if(resultado==1) {
									sonido = java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
						 	        sonido.play();
									JOptionPane.showMessageDialog(null, "Nombre de usuario ya existente :(","",JOptionPane.ERROR_MESSAGE,ico);
								}else {
									if(resultadoc==1) {
										sonido = java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
							 	        sonido.play();
										JOptionPane.showMessageDialog(null, "Correo electronico ya existente :(","",JOptionPane.ERROR_MESSAGE,ico);
									}else {
										//bueno
												String sqlInsert= "INSERT INTO usuario(Nombre, Apellido_Paterno, Apellido_Materno, Nombre_Usuario, Contrase�a, Correo, Nivel) VALUES ('"+Nom+"','"+Ap+"','"+Am+"','"+NomU+"','"+Contra+"','"+Correo+"',"+nivel+")";
												try {
											 		Statement stmt = con.createStatement();
									 	            stmt.executeUpdate(sqlInsert);
									 	           JOptionPane.showMessageDialog(null, "Usuario creado con exito" , "Insertar",JOptionPane.INFORMATION_MESSAGE);
									 	          
									 	        } catch (Exception e1) {
									 	   			JOptionPane.showMessageDialog(null, "HELP","",JOptionPane.ERROR_MESSAGE);
									 	        }
									}
								}
							}
						}
						
					}	
				}
					}
		});
		btnConfirmar.setBounds(10, 210, 135, 31);
		contentPane.add(btnConfirmar);
		
		JButton btnCancelar = new JButton(" Cancelar");
		btnCancelar.setIcon(new ImageIcon(CrearUsuario.class.getResource("/Imagenes/no.png")));
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnCancelar.setBounds(290, 210, 135, 31);
		contentPane.add(btnCancelar);
		
		lbleresEmpleado = new JLabel("\u00BFEres Empleado?");
		Font font = lbleresEmpleado.getFont();
		Map attributes = font.getAttributes();
		attributes.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON);
		lbleresEmpleado.setFont(font.deriveFont(attributes));
		lbleresEmpleado.setForeground(Color.BLUE);
		lbleresEmpleado.setCursor(new Cursor(HAND_CURSOR));
		lbleresEmpleado.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				id = JOptionPane.showInputDialog(null,"Ingrese su ID","Confirmacion",JOptionPane.QUESTION_MESSAGE);
				BindList();
				ShowPosInfo(0);
				}
		});
		lbleresEmpleado.setBounds(173, 216, 101, 19);
		contentPane.add(lbleresEmpleado);
	
	}
	
	static Connection conexion() {
		 Connection con1;
		 try {
			    Class.forName("com.mysql.jdbc.Driver");
			    con1 = DriverManager.getConnection("jdbc:mysql://localhost/nota","root", "");			   
			    return con1;
			} catch (Exception e) {
				 JOptionPane.showMessageDialog(null, "Error en la conexion con la Base de datos", "Error en B.D" ,JOptionPane.ERROR_MESSAGE);
				 }return null;
	}
	
	public static List<Vendedor> BindList(){
		 try{
	            Connection con = conexion();
	        	Statement stmt = con.createStatement();
	            ResultSet rs = stmt.executeQuery("SELECT * FROM vendedor WHERE Id_Vendedor=" + id);
	            List<Vendedor> list = new ArrayList<Vendedor>();
	            while(rs.next()){
	            	Vendedor u = new Vendedor(Integer.parseInt(rs.getString("Id_Vendedor")), 
	            			rs.getString("Nombre(s)"), 
	            			rs.getString("Apellido_Paterno"), 
	            			rs.getString("Apellido_Materno"));
	                list.add(u);
	            }
	            
	            return list;
	        }catch(Exception ex){
	        	
	        }
	        return null;
  	
  }
	
	 public void ShowPosInfo(int index){
		 try {
	        txtNom.setText(BindList().get(index).getNombre());
	        txtPaterno.setText(BindList().get(index).getA_paterno());
	        txtMaterno.setText(BindList().get(index).getA_materno());
	        
	        if(txtMaterno.getText().isEmpty()) {
	        txtNomUser.setText("000"+Integer.toString(BindList().get(index).getId())+BindList().get(index).getA_paterno().substring(0,2)+"_"+BindList().get(index).getNombre().toUpperCase().substring(0,1));
	        }else {
	        txtNomUser.setText("000"+Integer.toString(BindList().get(index).getId())+BindList().get(index).getA_paterno().substring(0,2)+"_"+BindList().get(index).getA_materno().substring(0,1)+"_"+BindList().get(index).getNombre().toUpperCase().substring(0,2));
	        }
	        
	        if(txtNom.getText().isEmpty()) {
			}else {
				txtNom.setEnabled(false);
				txtPaterno.setEnabled(false);
				txtMaterno.setEnabled(false);
				txtNomUser.setEnabled(false);
				nivel=2;
			}
	        
		 }catch(Exception e) {
			 JOptionPane.showMessageDialog(null, "ID no reconocido", "Error en B.D" ,JOptionPane.ERROR_MESSAGE);
		 }
	        
	        
	    }
}
