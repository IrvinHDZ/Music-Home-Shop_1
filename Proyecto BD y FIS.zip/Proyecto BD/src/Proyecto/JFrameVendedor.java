package Proyecto;

import java.applet.AudioClip;
import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;
import java.awt.Font;

public class JFrameVendedor extends JFrame {
	int pos=0;
	public	AudioClip sonido;
	ResultSet rs;
	PreparedStatement ps;
	boolean modoAgregar=false,modoEliminar=false,modoModificar=false;
	private JPanel contentPane;
	private JTextField txtId;
	private JTextField txtNom;
	private JTextField txtMaterno;
	private JTextField txtPaterno;
	private JButton btnI;
	private JButton btnA;
	private JButton btnS;
	private JButton btnU;
	private JButton btnAgregar;
	private JButton btnModificar;
	private JButton btnEliminar;
	private JButton btnConfirmar;
	private JButton btnCancelar;
	private JTextField txtRegistro;
	private JLabel lblModo;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JFrameVendedor frame = new JFrameVendedor();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public JFrameVendedor() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(JFrameVendedor.class.getResource("/Imagenes/profile.png")));
		Icon ico = new ImageIcon(getClass().getResource("/Proyecto/icono.gif"));
		setTitle("Base de Datos de los Vendedores");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 750, 340);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblId = new JLabel("Id Proveedor: ");
		lblId.setBounds(10, 11, 122, 14);
		contentPane.add(lblId);
		
		txtId = new JTextField();
		txtId.setEnabled(false);
		txtId.setBounds(142, 8, 190, 20);
		contentPane.add(txtId);
		txtId.setColumns(10);
		
		JLabel lblCompa = new JLabel("Nombre(s):");
		lblCompa.setBounds(10, 76, 122, 14);
		contentPane.add(lblCompa);
		
		txtNom = new JTextField();
		txtNom.setEnabled(false);
		txtNom.setBounds(142, 73, 190, 20);
		contentPane.add(txtNom);
		txtNom.setColumns(10);
		
		JLabel lblDire = new JLabel("Apellido Materno:");
		lblDire.setBounds(10, 183, 122, 14);
		contentPane.add(lblDire);
		
		txtMaterno = new JTextField();
		txtMaterno.setEnabled(false);
		txtMaterno.setBounds(142, 180, 190, 20);
		contentPane.add(txtMaterno);
		txtMaterno.setColumns(10);
		
		JLabel lblRfc = new JLabel("Apellido Paterno:");
		lblRfc.setBounds(10, 134, 122, 14);
		contentPane.add(lblRfc);
		
		txtPaterno = new JTextField();
		txtPaterno.setEnabled(false);
		txtPaterno.setBounds(142, 131, 190, 20);
		contentPane.add(txtPaterno);
		txtPaterno.setColumns(10);
		
		JButton btnSalir = new JButton(" Salir");
		btnSalir.setIcon(new ImageIcon(JFrameVendedor.class.getResource("/Imagenes/stock_exit.png")));
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnSalir.setBounds(604, 226, 120, 31);
		contentPane.add(btnSalir);
		
		btnI = new JButton("Inicio");
		btnI.setIcon(new ImageIcon(JFrameVendedor.class.getResource("/Imagenes/control_stop_left.png")));
		btnI.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pos = 0;
	            ShowPosInfo(pos);
			}
		});
		btnI.setBounds(10, 268, 139, 28);
		contentPane.add(btnI);
		
		btnA = new JButton("Anterior");
		btnA.setIcon(new ImageIcon(JFrameVendedor.class.getResource("/Imagenes/control_double_left.png")));
		btnA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pos--;
	            if(pos >= 0){
	                ShowPosInfo(pos);                
	            }
	            else{
	            	if(pos < 0){
	            		sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
	                    sonido.play(); 
	            		JOptionPane.showMessageDialog(null, "Ya es el primer registro","",JOptionPane.ERROR_MESSAGE,ico);
		                    pos = 0;            
		            }
	                
	            }
				
			}
		});
		btnA.setBounds(159, 268, 139, 28);
		contentPane.add(btnA);
		
		btnS = new JButton("Siguiente");
		btnS.setIcon(new ImageIcon(JFrameVendedor.class.getResource("/Imagenes/control_double_right.png")));
		btnS.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pos++;
	               if(pos < BindList().size()){
	                   ShowPosInfo(pos);
	               }
	               else{
	                   pos = BindList().size() - 1;
	                   ShowPosInfo(pos);
	                   sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
	                   sonido.play();
	           		JOptionPane.showMessageDialog(null, "Ya es el ultimo registro","",JOptionPane.ERROR_MESSAGE,ico);
	               }
			}
		});
		btnS.setBounds(436, 268, 139, 28);
		contentPane.add(btnS);
		
		btnU = new JButton("Ultimo");
		btnU.setIcon(new ImageIcon(JFrameVendedor.class.getResource("/Imagenes/control_stop_right.png")));
		btnU.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pos = BindList().size() - 1;
				ShowPosInfo(pos);
			}
		});
		btnU.setBounds(585, 268, 139, 28);
		contentPane.add(btnU);
		
		btnAgregar = new JButton(" Agregar");
		btnAgregar.setIcon(new ImageIcon(JFrameVendedor.class.getResource("/Imagenes/add.png")));
		btnAgregar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				modoAgregar=true;
				
				lblModo.setText("Modo: Agregar");
				
				lblId.setVisible(false);
				txtId.setVisible(false);
				btnAgregar.setVisible(false);
				btnModificar.setVisible(false);
				btnEliminar.setVisible(false);
				btnSalir.setVisible(false);
				btnI.setVisible(false);
				btnA.setVisible(false);
				btnS.setVisible(false);
				btnU.setVisible(false);
				txtRegistro.setVisible(false);
				
				btnCancelar.setVisible(true);
				btnConfirmar.setVisible(true);
				
				txtNom.setEnabled(true);
				txtPaterno.setEnabled(true);
				txtMaterno.setEnabled(true);
				
				txtId.setText("");
				txtNom.setText("");
				txtPaterno.setText("");
				txtMaterno.setText("");
				
			}
		});
		btnAgregar.setBounds(10, 226, 120, 31);
		contentPane.add(btnAgregar);
		
		btnModificar = new JButton(" Modificar");
		btnModificar.setIcon(new ImageIcon(JFrameVendedor.class.getResource("/Imagenes/refresh.png")));
		btnModificar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				modoModificar=true;
				
				lblModo.setText("Modo: Modificar");
				
				lblId.setVisible(false);
				txtId.setVisible(false);
				btnAgregar.setVisible(false);
				btnModificar.setVisible(false);
				btnEliminar.setVisible(false);
				btnSalir.setVisible(false);
				btnI.setVisible(false);
				btnA.setVisible(false);
				btnS.setVisible(false);
				btnU.setVisible(false);
				txtRegistro.setVisible(false);
				
				btnCancelar.setVisible(true);
				btnConfirmar.setVisible(true);
				
				txtNom.setEnabled(true);
				txtPaterno.setEnabled(true);
				txtMaterno.setEnabled(true);
				
			}
		});
		btnModificar.setBounds(212, 226, 120, 31);
		contentPane.add(btnModificar);
		
		btnEliminar = new JButton(" Eliminar");
		btnEliminar.setIcon(new ImageIcon(JFrameVendedor.class.getResource("/Imagenes/trash_can.png")));
		btnEliminar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				modoEliminar=true;
				
				lblModo.setText("Modo: Eliminar");
				
				btnAgregar.setVisible(false);
				btnModificar.setVisible(false);
				btnEliminar.setVisible(false);
				btnSalir.setVisible(false);
				btnI.setVisible(false);
				btnA.setVisible(false);
				btnS.setVisible(false);
				btnU.setVisible(false);
				txtRegistro.setVisible(false);
				
				btnCancelar.setVisible(true);
				btnConfirmar.setVisible(true);
				
				
			}
		});
		btnEliminar.setBounds(406, 226, 120, 31);
		contentPane.add(btnEliminar);
		
		btnConfirmar = new JButton(" Confirmar");
		btnConfirmar.setIcon(new ImageIcon(JFrameVendedor.class.getResource("/Imagenes/tick_circle.png")));
		btnConfirmar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int confirmado = JOptionPane.showConfirmDialog(null,"Presione YES para confirmar. \nPresione NO para anular accion.","Confirmacion",JOptionPane.YES_NO_OPTION);

				if (JOptionPane.YES_OPTION == confirmado) {
		String nombre, a_paterno,a_materno,id;
	    		
	    		
	    		if(modoAgregar==true){
		 			nombre=txtNom.getText().toUpperCase();
		 			a_paterno=txtPaterno.getText().toUpperCase();
		 			a_materno=txtMaterno.getText().toUpperCase();
		 			
		 		
		 		
		 		Connection con = conexion();
		 		
		 		if(nombre.isEmpty() ||  a_paterno.isEmpty()) {
		 			sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
		 	        sonido.play();		
		 			Icon ico=new ImageIcon(getClass().getResource("/Proyecto/icono.gif")); 
		 			JOptionPane.showMessageDialog(null, "Error al momento de agregar","",JOptionPane.ERROR_MESSAGE,ico);
		 			//JOptionPane.showMessageDialog(null, "Error al momento de agregar :(", "ERROR!!!" ,JOptionPane.ERROR_MESSAGE);
		 		}else {
		 			  String sqlInsert= "INSERT INTO `vendedor`(`Nombre(s)`, `Apellido_Paterno`, `Apellido_Materno`) values ('"+nombre+"','"+a_paterno+"','"+a_materno+"')";
		 		try {
		 		Statement stmt = con.createStatement();
 	            stmt.executeUpdate(sqlInsert);
 	           JOptionPane.showMessageDialog(btnAgregar, "Se ha guardado el Registro" , "Insertar",JOptionPane.INFORMATION_MESSAGE);
 	          
 	        } catch (Exception e1) {
 	        	sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
 	           sonido.play();		
 	   		Icon ico=new ImageIcon(getClass().getResource("/Proyecto/icono.gif")); 
 	   		JOptionPane.showMessageDialog(null, "Error al agregar","",JOptionPane.ERROR_MESSAGE,ico);
 	        }
		 		}
		 			modoAgregar=false;
		 			txtNom.setEnabled(false);
		 			txtPaterno.setEnabled(false);
		 			txtMaterno.setEnabled(false);
		 			txtId.setEnabled(false);
		 			
		 			txtId.setText("");
		 			txtNom.setText("");
		 			txtPaterno.setText("");
		 			txtMaterno.setText("");
		 			txtRegistro.setVisible(true);
		 			lblModo.setText("Modo: Lectura");
		 			lblId.setVisible(true);
		 			btnAgregar.setVisible(true);
		 			txtId.setVisible(true);
					btnEliminar.setVisible(true);
					btnModificar.setVisible(true);
					btnI.setVisible(true);
					btnS.setVisible(true);
					btnU.setVisible(true);
					btnA.setVisible(true);
					
					btnSalir.setVisible(true);
					
					
					btnConfirmar.setVisible(false);
					btnCancelar.setVisible(false);
					ShowPosInfo(0);
		 		}
	    		
	    		
	    		if(modoModificar==true) {
	    						 			
		 		id=txtId.getText();
		 		nombre=txtNom.getText().toUpperCase();
	 			a_paterno=txtPaterno.getText().toUpperCase();
	 			a_materno=txtMaterno.getText().toUpperCase();
		 		
		 		Connection con = conexion();
		 	//	String sqlupdate = "UPDATE proveedor SET Compa�ia = '"+ compa�ia + "',  RFC  = '"+ rfc +"', Direccion = '"+ direccion +"', Telefono = '"+ telefono +';
		 		String sqlupdate = "UPDATE `vendedor` SET `Id_Vendedor`='"+ id + "',  `Nombre(s)`  = '"+ nombre +"', `Apellido_Paterno` = '"+ a_paterno +"', `Apellido_Materno` = '"+ a_materno +"' WHERE Id_Vendedor = " + id ;
		 		if(nombre.isEmpty() ||  a_paterno.isEmpty()) {
		 			//JOptionPane.showMessageDialog(null, "Error al momento de modificar :(", "ERROR!!!" ,JOptionPane.ERROR_MESSAGE);
		 			sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
		 	        sonido.play();		
		 			Icon ico=new ImageIcon(getClass().getResource("/Proyecto/icono.gif")); 
		 			JOptionPane.showMessageDialog(null, "Error al momento de modificar","",JOptionPane.ERROR_MESSAGE,ico);
		 		}else {
		 			try {
		 	Statement stmt = con.createStatement();
 	           stmt.executeUpdate(sqlupdate);
 	          JOptionPane.showMessageDialog(btnAgregar, "Se han confirmado los cambios" , "Modificar",JOptionPane.INFORMATION_MESSAGE);
 	        } catch (Exception e1) {
 	        	sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
	 	        sonido.play();		
	 			Icon ico=new ImageIcon(getClass().getResource("/Proyecto/icono.gif")); 
	 			JOptionPane.showMessageDialog(null, "Error al momento de modificar","",JOptionPane.ERROR_MESSAGE,ico);
 	        	//JOptionPane.showMessageDialog(btnModificar, "No se confirmo el cambio del(os)   registro(s)","Modificar",JOptionPane.ERROR_MESSAGE);
 	        }
		 		}
		 				
	    			modoModificar=false;
	    			txtNom.setEnabled(false);
		 			txtPaterno.setEnabled(false);
		 			txtMaterno.setEnabled(false);
		 			txtId.setEnabled(false);
		 			
		 			txtId.setText("");
		 			txtNom.setText("");
		 			txtPaterno.setText("");
		 			txtMaterno.setText("");
		 			txtRegistro.setVisible(true);
		 			lblModo.setText("Modo: Lectura");
		 			lblId.setVisible(true);
		 			btnAgregar.setVisible(true);
		 			txtId.setVisible(true);
					btnEliminar.setVisible(true);
					btnModificar.setVisible(true);
					btnI.setVisible(true);
					btnS.setVisible(true);
					btnU.setVisible(true);
					btnA.setVisible(true);
					
					btnSalir.setVisible(true);
					
					
					btnConfirmar.setVisible(false);
					btnCancelar.setVisible(false);
					ShowPosInfo(pos);
	    		}
	    		if(modoEliminar==true) {
	    			
		 			
		 			id =  txtId.getText();
		 			String SqlSt = "DELETE FROM vendedor WHERE Id_Vendedor= "+ id;
		 			Connection con = conexion();
		 	        try {
		 	        	Statement stmt = con.createStatement();
		 	            stmt.executeUpdate(SqlSt);
		 	           
		 	           JOptionPane.showMessageDialog(btnEliminar, "Eliminacion Exitosa","Eliminar",JOptionPane.INFORMATION_MESSAGE);
		 	        } catch (Exception e1) {
		 	        	sonido=java.applet.Applet.newAudioClip(getClass().getResource("/Proyecto/AudioCutter_�Ah, ah, ah! �No dijiste la palabra m�gica! xd.wav"));
		 	           sonido.play();		
		 	   		Icon ico=new ImageIcon(getClass().getResource("/Proyecto/icono.gif")); 
		 	   		JOptionPane.showMessageDialog(null, "No se pudo eliminar","",JOptionPane.ERROR_MESSAGE,ico);
		 	           // JOptionPane.showMessageDialog(null, "No se pudo eliminar los registros.",  "ERROR !!!",JOptionPane.ERROR_MESSAGE);
		 	        }
	    			
	    			
	    			
	    			modoEliminar=false;
	    			txtNom.setEnabled(false);
		 			txtPaterno.setEnabled(false);
		 			txtMaterno.setEnabled(false);
		 			txtId.setEnabled(false);
		 			
		 			txtId.setText("");
		 			txtNom.setText("");
		 			txtPaterno.setText("");
		 			txtMaterno.setText("");
		 			txtRegistro.setVisible(true);
		 			lblModo.setText("Modo: Lectura");
		 			lblId.setVisible(true);
		 			btnAgregar.setVisible(true);
		 			txtId.setVisible(true);
					btnEliminar.setVisible(true);
					btnModificar.setVisible(true);
					btnI.setVisible(true);
					btnS.setVisible(true);
					btnU.setVisible(true);
					btnA.setVisible(true);
					
					btnSalir.setVisible(true);
					
					
					btnConfirmar.setVisible(false);
					btnCancelar.setVisible(false);
					ShowPosInfo(0);
	    		}
			}
			}
		});
		btnConfirmar.setBounds(342, 184, 135, 31);
		btnConfirmar.setVisible(false);
		contentPane.add(btnConfirmar);
		
		btnCancelar = new JButton(" Cancelar");
		btnCancelar.setIcon(new ImageIcon(JFrameVendedor.class.getResource("/Imagenes/no.png")));
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				modoAgregar=false;
				modoEliminar=false;
				modoModificar=false;
				
				lblModo.setText("Modo: Lectura");
				
				lblId.setVisible(true);
				txtId.setVisible(true);
				btnAgregar.setVisible(true);
				btnModificar.setVisible(true);
				btnEliminar.setVisible(true);
				btnSalir.setVisible(true);
				btnI.setVisible(true);
				btnA.setVisible(true);
				btnS.setVisible(true);
				btnU.setVisible(true);
				txtRegistro.setVisible(true);
				
				btnCancelar.setVisible(false);
				btnConfirmar.setVisible(false);
				
				txtNom.setEnabled(false);
				txtPaterno.setEnabled(false);
				txtMaterno.setEnabled(false);
				
				txtId.setText("");
				txtNom.setText("");
				txtPaterno.setText("");
				txtMaterno.setText("");
			
				ShowPosInfo(0);
			}
		});
		btnCancelar.setBounds(516, 184, 135, 31);
		btnCancelar.setVisible(false);
		contentPane.add(btnCancelar);
		
		txtRegistro = new JTextField();
		txtRegistro.setFont(new Font("Tahoma", Font.BOLD, 13));
		txtRegistro.setEnabled(false);
		txtRegistro.setBounds(308, 268, 118, 28);
		contentPane.add(txtRegistro);
		txtRegistro.setColumns(10);
		
		lblModo = new JLabel("Modo: Lectura");
		lblModo.setBounds(406, 11, 130, 14);
		contentPane.add(lblModo);
		
		ShowPosInfo(0);
	}
	
	
	
	static Connection conexion() {
		 Connection con1;
		 try {
			    Class.forName("com.mysql.jdbc.Driver");
			    con1 = DriverManager.getConnection("jdbc:mysql://localhost/nota","root", "");			   
			    return con1;
			} catch (Exception e) {
				 JOptionPane.showMessageDialog(null, "Error en la conexion con la Base de datos", "Error en B.D" ,JOptionPane.ERROR_MESSAGE);
				 }return null;
	}
	public static List<Vendedor> BindList(){
		 try{
	            Connection con = conexion();
	        	Statement stmt = con.createStatement();
	            ResultSet rs = stmt.executeQuery("SELECT * FROM  vendedor ");
	            List<Vendedor> list = new ArrayList<Vendedor>();
	            while(rs.next()){
	            	
	            	Vendedor u = new Vendedor(Integer.parseInt(rs.getString("Id_Vendedor")), 
	            			rs.getString("Nombre(s)"), 
	            			rs.getString("Apellido_Paterno"), 
	            			rs.getString("Apellido_Materno"));
	       
	                list.add(u);
	            }
	            
	            return list;
	        }catch(Exception ex){
	        	JOptionPane.showMessageDialog(null, "efjrgehjrg", "Error en B.D" ,JOptionPane.ERROR_MESSAGE);
	        }
	        return null;
   	
   }
	
	 public void ShowPosInfo(int index){
		 try {
			txtId.setText(Integer.toString(BindList().get(index).getId()));
	        txtNom.setText(BindList().get(index).getNombre());
	        txtPaterno.setText(BindList().get(index).getA_paterno());
	        txtMaterno.setText(BindList().get(index).getA_materno());
	       
	        txtRegistro.setText("Registro # " +Integer.toString(pos+1));
		 }catch(Exception the) {
			 JOptionPane.showMessageDialog(null, "Datos no encontrados", "Error en B.D" ,JOptionPane.ERROR_MESSAGE);
		 }
	        
	        
	    }
		
}
