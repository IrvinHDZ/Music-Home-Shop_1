package Proyecto;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.font.TextAttribute;
import java.awt.event.ActionEvent;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.JLabel;
import javax.swing.JSpinner;
import java.applet.AudioClip;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JRadioButton;
import javax.swing.SpinnerNumberModel;
import javax.swing.ButtonGroup;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.Color;
import java.awt.Cursor;

import javax.swing.ImageIcon;
import javax.swing.JPasswordField;

public class Formulario extends JFrame {
private JFrame frmLaBaseDe;

private JTextField txtuser;
private JPasswordField passwordField;

	public static void main(String[] args) {
		
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					 Formulario window = new  Formulario();
					window.frmLaBaseDe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public  Formulario() {
		initialize();
	}

	private void initialize() {
		String sql="";
		frmLaBaseDe = new JFrame();
		frmLaBaseDe.setIconImage(Toolkit.getDefaultToolkit().getImage(JFrameProductos.class.getResource("/Imagenes/gdm_login_photo.png")));
		frmLaBaseDe.setTitle("Iniciar Sesion");
		frmLaBaseDe.setResizable(false);
		frmLaBaseDe.setBounds(100, 100, 480, 256);
		frmLaBaseDe.getContentPane().setLayout(null);
		
		JButton btnConfirmar = new JButton("Confirmar");
		btnConfirmar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnConfirmar.setIcon(new ImageIcon(Formulario.class.getResource("/Imagenes/tick_circle.png")));
		btnConfirmar.setBounds(44, 164, 135, 31);
		frmLaBaseDe.getContentPane().add(btnConfirmar);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnCancelar.setIcon(new ImageIcon(Formulario.class.getResource("/Imagenes/stock_exit.png")));
		btnCancelar.setBounds(239, 164, 135, 31);
		frmLaBaseDe.getContentPane().add(btnCancelar);
		
		JLabel lbl = new JLabel("Nombre de usuario:");
		lbl.setBounds(39, 26, 113, 14);
		frmLaBaseDe.getContentPane().add(lbl);
		
		JLabel lblContrasea = new JLabel("Contrase\u00F1a:");
		lblContrasea.setBounds(39, 82, 113, 14);
		frmLaBaseDe.getContentPane().add(lblContrasea);
		
		txtuser = new JTextField();
		txtuser.setBounds(162, 22, 165, 22);
		frmLaBaseDe.getContentPane().add(txtuser);
		txtuser.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(162, 78, 165, 22);
		frmLaBaseDe.getContentPane().add(passwordField);
		
		JLabel lblCambio = new JLabel("Olvide la contrase\u00F1a");
		Font font = lblCambio.getFont();
		Map attributes = font.getAttributes();
		attributes.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON);
		lblCambio.setFont(font.deriveFont(attributes));
		lblCambio.setForeground(Color.BLUE);
		lblCambio.setCursor(new Cursor(HAND_CURSOR));
		lblCambio.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				}
		});
		lblCambio.setBounds(168, 128, 117, 14);
		frmLaBaseDe.getContentPane().add(lblCambio);
		
		JCheckBox chckbxCambiar = new JCheckBox("Cambiar A \r\nCorreo");
		chckbxCambiar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(chckbxCambiar.isSelected()==true){
			lbl.setText("Correo electronico:");
			}else {
				lbl.setText("Nombre de usuario:");
			}
			}
		});
		chckbxCambiar.setBounds(333, 23, 135, 14);
		
		frmLaBaseDe.getContentPane().add(chckbxCambiar);
		
		
		
		
	}
	private static Connection conexion() {
		 Connection con1;
		 try {
			    Class.forName("com.mysql.jdbc.Driver").newInstance();
			    con1 = DriverManager.getConnection("jdbc:mysql://localhost/bd1","root", "");
			   //JOptionPane.showMessageDialog(null, "Si se conecto a la Base de datos", "exito" ,JOptionPane.INFORMATION_MESSAGE);
			   // System.out.println("Registro exitoso");
			    //Statement cmd = con.createStatement();
			    return con1;
			} catch (Exception e) {
				 JOptionPane.showMessageDialog(null, e.toString(), "Eror en B.D" ,JOptionPane.ERROR_MESSAGE);
			    //System.out.println(e.toString());

			}return null;
		 
	}

	
}